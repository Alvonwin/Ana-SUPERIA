const fs = require('fs');

const filePath = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(filePath, 'utf8');

// Pattern à remplacer
const oldCode = `      response = await router.query(model, antiRepetitionPrompt, false);
      repetitionCheck = globalDetector.check(response.response, 'chat_main');`;

const newCode = `      // FIX 2025-12-17: Utiliser le bon service selon le provider (Cerebras vs Ollama)
      const isCerebrasModel = model && (model.includes('cerebras') || model === 'llama-3.3-70b');
      if (isCerebrasModel) {
        const cerebrasResult = await cerebrasService.chat(antiRepetitionPrompt, {
          model: 'llama-3.3-70b',
          systemPrompt: currentSystemPrompt
        });
        response = { response: cerebrasResult.response || cerebrasResult.content };
      } else {
        response = await router.query(model, antiRepetitionPrompt, false);
      }
      repetitionCheck = globalDetector.check(response.response, 'chat_main');`;

if (content.includes(oldCode)) {
  content = content.replace(oldCode, newCode);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✅ Bug RepetitionDetector corrigé - Cerebras maintenant supporté');
} else {
  console.log('❌ Pattern non trouvé - vérifier le fichier');
  // Essayer de trouver une version similaire
  if (content.includes('router.query(model, antiRepetitionPrompt')) {
    console.log('  Pattern partiel trouvé, recherche élargie...');
  }
}
