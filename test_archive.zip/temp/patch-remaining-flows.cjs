// Patch les autres flux qui utilisent runToolAgentV2 dans ana-core.cjs
const fs = require('fs');
const path = 'E:/ANA/server/ana-core.cjs';

let content = fs.readFileSync(path, 'utf8');
let patchCount = 0;

// Pattern 1: flux chat_v2 tools (ligne ~3540)
const old1 = `        if (expertType === 'tools') {
          const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_v2',
            context: memoryContext
          });
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
        }`;

const new1 = `        if (expertType === 'tools') {
          const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_v2',
            context: memoryContext
          });
          // FIX 2025-12-17: Extraire tool patterns pour apprentissage
          const toolsUsedV2 = toolResult?.stats?.toolCallCounts || {};
          if (Object.keys(toolsUsedV2).length > 0) {
            skillLearner.extractSkillsFromConversation({
              userMessage: message,
              anaResponse: toolResult.answer || '',
              model: toolResult.model || 'tool-agent',
              success: toolResult.success,
              toolsUsed: toolsUsedV2
            }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
          }
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
        }`;

if (content.includes(old1)) {
  content = content.replace(old1, new1);
  patchCount++;
  console.log('✅ Patch 1 appliqué (chat_v2 tools)');
}

// Pattern 2: flux chat_v2 research (ligne ~3547)
const old2 = `        else if (expertType === 'research') {
          const toolResult = await toolAgent.runToolAgentV2(message, {
            // FIX 2025-12-15: Pas de model hardcodé
            sessionId: 'chat_v2',
            context: memoryContext
          });
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';
        }`;

const new2 = `        else if (expertType === 'research') {
          const toolResult = await toolAgent.runToolAgentV2(message, {
            // FIX 2025-12-15: Pas de model hardcodé
            sessionId: 'chat_v2',
            context: memoryContext
          });
          // FIX 2025-12-17: Extraire tool patterns pour apprentissage
          const toolsUsedV2Research = toolResult?.stats?.toolCallCounts || {};
          if (Object.keys(toolsUsedV2Research).length > 0) {
            skillLearner.extractSkillsFromConversation({
              userMessage: message,
              anaResponse: toolResult.answer || '',
              model: toolResult.model || 'tool-agent',
              success: toolResult.success,
              toolsUsed: toolsUsedV2Research
            }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
          }
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';
        }`;

if (content.includes(old2)) {
  content = content.replace(old2, new2);
  patchCount++;
  console.log('✅ Patch 2 appliqué (chat_v2 research)');
}

// Pattern 3: autre flux tools (ligne ~5140)
const old3 = `          if (expertType === 'tools') {
            const toolResult = await toolAgent.runToolAgentV2(message, {
              sessionId: 'chat_main',
              context: memoryContext
            });
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
          }`;

const new3 = `          if (expertType === 'tools') {
            const toolResult = await toolAgent.runToolAgentV2(message, {
              sessionId: 'chat_main',
              context: memoryContext
            });
            // FIX 2025-12-17: Extraire tool patterns pour apprentissage
            const toolsUsedMain = toolResult?.stats?.toolCallCounts || {};
            if (Object.keys(toolsUsedMain).length > 0) {
              skillLearner.extractSkillsFromConversation({
                userMessage: message,
                anaResponse: toolResult.answer || '',
                model: toolResult.model || 'tool-agent',
                success: toolResult.success,
                toolsUsed: toolsUsedMain
              }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
            }
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
          }`;

if (content.includes(old3)) {
  content = content.replace(old3, new3);
  patchCount++;
  console.log('✅ Patch 3 appliqué (autre flux tools)');
}

// Pattern 4: autre flux research (ligne ~5147)
const old4 = `          else if (expertType === 'research') {
            const toolResult = await toolAgent.runToolAgentV2(message, {
              // FIX 2025-12-15: Pas de model hardcodé
              sessionId: 'chat_main',
              context: memoryContext
            });
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';
          }`;

const new4 = `          else if (expertType === 'research') {
            const toolResult = await toolAgent.runToolAgentV2(message, {
              // FIX 2025-12-15: Pas de model hardcodé
              sessionId: 'chat_main',
              context: memoryContext
            });
            // FIX 2025-12-17: Extraire tool patterns pour apprentissage
            const toolsUsedMainResearch = toolResult?.stats?.toolCallCounts || {};
            if (Object.keys(toolsUsedMainResearch).length > 0) {
              skillLearner.extractSkillsFromConversation({
                userMessage: message,
                anaResponse: toolResult.answer || '',
                model: toolResult.model || 'tool-agent',
                success: toolResult.success,
                toolsUsed: toolsUsedMainResearch
              }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
            }
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';
          }`;

if (content.includes(old4)) {
  content = content.replace(old4, new4);
  patchCount++;
  console.log('✅ Patch 4 appliqué (autre flux research)');
}

fs.writeFileSync(path, content, 'utf8');
console.log(`\nTotal: ${patchCount} patches appliqués`);
