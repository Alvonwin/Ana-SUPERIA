/**
 * Fix: Passer les images uploadées au tool-agent
 *
 * Problème: Les images uploadées par l'utilisateur ne sont PAS passées au tool-agent
 * Résultat: Le LLM invente des chemins de fichiers
 *
 * Solution: Passer images dans le contexte de runToolAgentV2
 */
const fs = require('fs');

console.log('═══════════════════════════════════════════════════════');
console.log('  FIX: Passer images uploadées au tool-agent');
console.log('═══════════════════════════════════════════════════════');
console.log('');

// === 1. Mettre à jour ana-core.cjs ===
const anaCoreFile = 'E:/ANA/server/ana-core.cjs';
let anaCore = fs.readFileSync(anaCoreFile, 'utf8');

// Backup
fs.writeFileSync(anaCoreFile + '.backup_images_' + Date.now(), anaCore, 'utf8');
console.log('✅ Backup ana-core.cjs');

// Compter les modifications
let modCount = 0;

// Pattern: runToolAgentV2(message, { ... }) sans images
// On doit ajouter images au contexte

// Trouver tous les appels runToolAgentV2 dans le handler WebSocket (après socket.on('chat:message'))
// et ajouter images au contexte

// Pattern 1: const result = await toolAgent.runToolAgentV2(message, {\n            model: model,
const pattern1 = `const result = await toolAgent.runToolAgentV2(message, {
            model: model,
            useLoopController: true  // Active boucle intelligente sans limite fixe
          });`;

const replacement1 = `const result = await toolAgent.runToolAgentV2(message, {
            model: model,
            useLoopController: true,  // Active boucle intelligente sans limite fixe
            images: images  // FIX 2025-12-18: Passer les images uploadées
          });`;

if (anaCore.includes(pattern1)) {
  anaCore = anaCore.replace(pattern1, replacement1);
  modCount++;
  console.log('✅ Ajouté images à runToolAgentV2 (pattern 1)');
}

// Pattern 2: Dans les appels avec sessionId
const pattern2 = `const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_main',
            context: memoryContext
          });`;

const replacement2 = `const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_main',
            context: memoryContext,
            images: images  // FIX 2025-12-18: Passer les images uploadées
          });`;

while (anaCore.includes(pattern2)) {
  anaCore = anaCore.replace(pattern2, replacement2);
  modCount++;
}
console.log(`✅ Ajouté images à runToolAgentV2 (${modCount} occurrences sessionId:chat_main)`);

// Pattern 3: sessionId: 'chat_v2'
const pattern3 = `const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_v2',
            context: memoryContext
          });`;

const replacement3 = `const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: 'chat_v2',
            context: memoryContext,
            images: images  // FIX 2025-12-18: Passer les images uploadées
          });`;

let modCount3 = 0;
while (anaCore.includes(pattern3)) {
  anaCore = anaCore.replace(pattern3, replacement3);
  modCount3++;
}
console.log(`✅ Ajouté images à runToolAgentV2 (${modCount3} occurrences sessionId:chat_v2)`);

fs.writeFileSync(anaCoreFile, anaCore, 'utf8');
console.log('');

// === 2. Mettre à jour tool-agent.cjs pour utiliser images du contexte ===
const toolAgentFile = 'E:/ANA/server/agents/tool-agent.cjs';
let toolAgent = fs.readFileSync(toolAgentFile, 'utf8');

// Backup
fs.writeFileSync(toolAgentFile + '.backup_images_' + Date.now(), toolAgent, 'utf8');
console.log('✅ Backup tool-agent.cjs');

// Trouver runToolAgentV2 et s'assurer que images est extrait du options
const oldRunToolAgentV2 = `async runToolAgentV2(userMessage, options = {}) {
    const {
      model = 'qwen2.5-coder:7b',`;

const newRunToolAgentV2 = `async runToolAgentV2(userMessage, options = {}) {
    const {
      model = 'qwen2.5-coder:7b',
      images = [],  // FIX 2025-12-18: Images uploadées par l'utilisateur`;

if (toolAgent.includes(oldRunToolAgentV2)) {
  toolAgent = toolAgent.replace(oldRunToolAgentV2, newRunToolAgentV2);
  console.log('✅ Ajouté extraction images dans runToolAgentV2');
} else {
  console.log('⚠️ Pattern runToolAgentV2 non trouvé - vérification manuelle');
}

// Modifier describe_image pour utiliser images du contexte
const oldDescribeImage = `  async describe_image(args) {
    const { image_path, image_base64, prompt } = args;
    console.log(\`👁️ [ToolAgent] describe_image: \${image_path || 'base64 image'}\`);
    try {
      // Utilise vision-router avec sélection automatique du modèle
      const result = await visionRouter.analyze({
        imagePath: image_path,
        imageBase64: image_base64,
        prompt: prompt || 'Décris cette image en détail.',
        taskType: 'description'  // Moondream (rapide) par défaut
      });
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  },`;

const newDescribeImage = `  async describe_image(args, context = {}) {
    const { image_path, image_base64, prompt } = args;

    // FIX 2025-12-18: Utiliser l'image uploadée si disponible
    let imageToUse = image_base64;
    if (!imageToUse && context.images && context.images.length > 0) {
      imageToUse = context.images[0];
      console.log('👁️ [ToolAgent] describe_image: Utilisation image uploadée');
    } else {
      console.log(\`👁️ [ToolAgent] describe_image: \${image_path || 'base64 image'}\`);
    }

    try {
      // Utilise vision-router avec sélection automatique du modèle
      const result = await visionRouter.analyze({
        imagePath: imageToUse ? null : image_path,  // Ignorer path si on a base64
        imageBase64: imageToUse,
        prompt: prompt || 'Décris cette image en détail.',
        taskType: 'description'  // Moondream (rapide) par défaut
      });
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  },`;

if (toolAgent.includes(oldDescribeImage)) {
  toolAgent = toolAgent.replace(oldDescribeImage, newDescribeImage);
  console.log('✅ describe_image utilise maintenant les images du contexte');
} else {
  console.log('⚠️ Pattern describe_image non trouvé exactement');
}

fs.writeFileSync(toolAgentFile, toolAgent, 'utf8');

console.log('');
console.log('═══════════════════════════════════════════════════════');
console.log('  CORRECTIONS APPLIQUÉES');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('1. ana-core.cjs: images passées à runToolAgentV2');
console.log('2. tool-agent.cjs: describe_image utilise images du contexte');
console.log('');
console.log('Résultat attendu:');
console.log('- Upload image → describe_image reçoit le base64 → analyse OK');
console.log('');
