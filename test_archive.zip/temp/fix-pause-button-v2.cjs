/**
 * FIX 2025-12-18: Corriger le bouton Pause pour edge-tts
 * Version 2: Patterns plus flexibles
 */
const fs = require('fs');

const file = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(file, 'utf8');

let changes = 0;

// === FIX 1: Ajouter le ref pour l'audio ===
if (!content.includes('currentAudioRef')) {
  content = content.replace(
    /const fileInputRef = useRef\(null\);/,
    `const fileInputRef = useRef(null);
  const currentAudioRef = useRef(null); // FIX 2025-12-18: Stocker audio edge-tts pour pause`
  );
  changes++;
  console.log('✅ FIX 1: Ref currentAudioRef ajouté');
} else {
  console.log('ℹ️ FIX 1: Ref déjà présent');
}

// === FIX 2: Modifier handlePlayPause pour arrêter l'audio ===
if (!content.includes('currentAudioRef.current.pause()')) {
  content = content.replace(
    /if \(playingAudio === messageId\) \{\s*\n\s*if \(window\.speechSynthesis\) window\.speechSynthesis\.cancel\(\);\s*\n\s*setPlayingAudio\(null\);\s*\n\s*return;\s*\n\s*\}/,
    `if (playingAudio === messageId) {
      // FIX 2025-12-18: Arrêter l'audio edge-tts
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setPlayingAudio(null);
      return;
    }`
  );
  changes++;
  console.log('✅ FIX 2: handlePlayPause modifié pour arrêter audio');
} else {
  console.log('ℹ️ FIX 2: Déjà corrigé');
}

// === FIX 3: Modifier speakWithEdgeTTS pour stocker l'audio ===
if (!content.includes('currentAudioRef.current = audio')) {
  content = content.replace(
    /audio\.play\(\);\s*\n\s*return audio;/,
    `currentAudioRef.current = audio; // FIX 2025-12-18: Stocker pour pause
      audio.play();
      return audio;`
  );
  changes++;
  console.log('✅ FIX 3: speakWithEdgeTTS stocke maintenant l\'audio');
} else {
  console.log('ℹ️ FIX 3: Déjà corrigé');
}

// Écrire si changements
if (changes > 0) {
  fs.writeFileSync(file, content, 'utf8');
  console.log(`\n✅ ${changes} fix(es) appliqué(s) à ChatPage.jsx`);
  console.log('Le bouton Pause fonctionnera maintenant avec edge-tts/Sylvie');
} else {
  console.log('\nℹ️ Tous les fixes sont déjà appliqués');
}

console.log('\nRedémarre le frontend Ana pour appliquer.');
