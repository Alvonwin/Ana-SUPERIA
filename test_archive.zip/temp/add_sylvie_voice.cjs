const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// 1. Ajouter la constante SYLVIE_VOICE après les imports
const importMarker = "import { BACKEND_URL } from '../config';";
const sylvieConst = `import { BACKEND_URL } from '../config';

// Voix Sylvie (Québec) via edge-tts backend
const SYLVIE_VOICE = 'Sylvie (Québec)';`;

if (!content.includes('SYLVIE_VOICE')) {
  content = content.replace(importMarker, sylvieConst);
  console.log('✓ Constante SYLVIE_VOICE ajoutée');
} else {
  console.log('⚠ SYLVIE_VOICE déjà présent');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
