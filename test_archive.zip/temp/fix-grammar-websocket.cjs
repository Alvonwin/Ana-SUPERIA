/**
 * FIX 2025-12-18: Ajouter grammarService.correct() sur les chemins WebSocket
 */
const fs = require('fs');

const file = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
const backupFile = file + '.backup_grammar_fix_' + Date.now();
fs.writeFileSync(backupFile, content, 'utf8');
console.log('✅ Backup créé:', backupFile);

let changes = 0;

// === FIX 1: Conscience (après ligne ~5244) ===
const pattern1_old = `          // Spell check
          finalResponse = spellChecker.correctText(finalResponse);

          // Simuler le streaming`;

const pattern1_new = `          // Spell check
          finalResponse = spellChecker.correctText(finalResponse);

          // Grammar correction (LanguageTool) - FIX 2025-12-18
          try {
            finalResponse = await grammarService.correct(finalResponse);
          } catch (gramErr) { /* ignore */ }

          // Simuler le streaming`;

if (content.includes(pattern1_old) && !content.includes('Grammar correction (LanguageTool) - FIX 2025-12-18')) {
  content = content.replace(pattern1_old, pattern1_new);
  changes++;
  console.log('✅ FIX 1 (Conscience) appliqué');
} else if (content.includes('Grammar correction (LanguageTool) - FIX 2025-12-18')) {
  console.log('ℹ️ FIX 1 déjà présent');
} else {
  console.log('⚠️ FIX 1: Pattern non trouvé');
}

// === FIX 2: GROQ (après ligne ~5369) ===
const pattern2_old = `            let filteredGroq = forceTutoiement(groqResult.response);
            filteredGroq = spellChecker.correctText(filteredGroq);
            console.log(\`⚡ [GROQ] Réponse:`;

const pattern2_new = `            let filteredGroq = forceTutoiement(groqResult.response);
            filteredGroq = spellChecker.correctText(filteredGroq);
            // Grammar correction (LanguageTool) - FIX 2025-12-18
            try {
              filteredGroq = await grammarService.correct(filteredGroq);
            } catch (gramErr) { /* ignore */ }
            console.log(\`⚡ [GROQ] Réponse:`;

if (content.includes(pattern2_old)) {
  content = content.replace(pattern2_old, pattern2_new);
  changes++;
  console.log('✅ FIX 2 (GROQ) appliqué');
} else {
  console.log('⚠️ FIX 2: Pattern non trouvé ou déjà appliqué');
}

// === FIX 3: Cerebras (après ligne ~5405) ===
const pattern3_old = `            let filteredCerebras = forceTutoiement(cerebrasResult.response);
            filteredCerebras = spellChecker.correctText(filteredCerebras);
            console.log(\`🧠 [CEREBRAS] Réponse:`;

const pattern3_new = `            let filteredCerebras = forceTutoiement(cerebrasResult.response);
            filteredCerebras = spellChecker.correctText(filteredCerebras);
            // Grammar correction (LanguageTool) - FIX 2025-12-18
            try {
              filteredCerebras = await grammarService.correct(filteredCerebras);
            } catch (gramErr) { /* ignore */ }
            console.log(\`🧠 [CEREBRAS] Réponse:`;

if (content.includes(pattern3_old)) {
  content = content.replace(pattern3_old, pattern3_new);
  changes++;
  console.log('✅ FIX 3 (Cerebras) appliqué');
} else {
  console.log('⚠️ FIX 3: Pattern non trouvé ou déjà appliqué');
}

// === FIX 4: Ollama Streaming (après ligne ~6165) ===
const pattern4_old = `        // Force tutoiement (vous→tu) - Post-processing obligatoire
        correctedResponse = forceTutoiement(correctedResponse);

        memory.appendToContext`;

const pattern4_new = `        // Force tutoiement (vous→tu) - Post-processing obligatoire
        correctedResponse = forceTutoiement(correctedResponse);

        // Grammar correction (LanguageTool) - FIX 2025-12-18
        try {
          correctedResponse = await grammarService.correct(correctedResponse);
        } catch (gramErr) { /* ignore */ }

        memory.appendToContext`;

if (content.includes(pattern4_old)) {
  content = content.replace(pattern4_old, pattern4_new);
  changes++;
  console.log('✅ FIX 4 (Ollama streaming) appliqué');
} else {
  console.log('⚠️ FIX 4: Pattern non trouvé ou déjà appliqué');
}

// Écrire si changements
if (changes > 0) {
  fs.writeFileSync(file, content, 'utf8');
  console.log(`\n✅ ${changes} fix(es) appliqué(s) à ana-core.cjs`);
} else {
  console.log('\nℹ️ Aucun changement nécessaire');
}

console.log('\nRedémarre Ana pour appliquer.');
