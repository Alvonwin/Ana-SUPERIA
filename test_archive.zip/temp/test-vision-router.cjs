/**
 * Test Vision Router - Moondream vs Llama Vision
 */
const visionRouter = require('../intelligence/vision/vision-router.cjs');

const testImage = 'E:/Mémoire Claude/screenshot_question.jpg';

async function runTests() {
  console.log('═══════════════════════════════════════════════════════');
  console.log('  TEST VISION ROUTER - Ana SUPERIA');
  console.log('═══════════════════════════════════════════════════════');
  console.log('');

  // Test 1: Quick description (should use Moondream)
  console.log('📸 TEST 1: Description rapide (Moondream attendu)');
  console.log('─────────────────────────────────────────────────────');
  const start1 = Date.now();
  const result1 = await visionRouter.quickDescribe(testImage);
  const time1 = Date.now() - start1;

  console.log('Modèle utilisé:', result1.model);
  console.log('Temps:', time1, 'ms');
  console.log('Succès:', result1.success);
  if (result1.success) {
    console.log('Réponse:', result1.response.substring(0, 200) + '...');
  } else {
    console.log('Erreur:', result1.error);
  }
  console.log('');

  // Test 2: Auto-selection with "description" task
  console.log('📸 TEST 2: Auto-sélection (taskType: description)');
  console.log('─────────────────────────────────────────────────────');
  const result2 = await visionRouter.analyze({
    imagePath: testImage,
    prompt: 'Que vois-tu dans cette image?',
    taskType: 'description'
  });
  console.log('Modèle utilisé:', result2.model);
  console.log('Temps:', result2.latencyMs, 'ms');
  console.log('');

  // Test 3: Auto-selection with "ocr" task (should use Llama Vision)
  console.log('📸 TEST 3: Auto-sélection (taskType: ocr) - LLAMA VISION attendu');
  console.log('─────────────────────────────────────────────────────');
  console.log('⏳ Ceci peut prendre 30-60 secondes (chargement modèle 8GB)...');
  const start3 = Date.now();
  const result3 = await visionRouter.extractText(testImage);
  const time3 = Date.now() - start3;

  console.log('Modèle utilisé:', result3.model);
  console.log('Temps:', time3, 'ms');
  console.log('Succès:', result3.success);
  if (result3.success) {
    console.log('Réponse:', result3.response.substring(0, 300) + '...');
  } else {
    console.log('Erreur:', result3.error);
  }
  console.log('');

  // Stats
  console.log('═══════════════════════════════════════════════════════');
  console.log('  STATISTIQUES');
  console.log('═══════════════════════════════════════════════════════');
  const stats = visionRouter.getStats();
  console.log('Moondream:', stats.moondream);
  console.log('Llama Vision:', stats.llama_vision);
  console.log('');

  console.log('═══════════════════════════════════════════════════════');
  console.log('  TESTS TERMINÉS');
  console.log('═══════════════════════════════════════════════════════');
}

runTests().catch(err => {
  console.error('Test failed:', err.message);
});
