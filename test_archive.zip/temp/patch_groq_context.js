// Patch ana-direct.cjs pour passer le contexte de conversation à Groq
const fs = require('fs');
const path = 'E:/ANA/server/intelligence/ana-direct.cjs';

let content = fs.readFileSync(path, 'utf8');

// Ancien: groq.chat(message) sans contexte
const oldGroq = `if (isSimpleMessage(message)) {
      console.log('[ANA-DIRECT] Simple → Groq');
      const groqSvc = require('../services/groq-service.cjs');
      groqSvc.initialize();
      const gr = await groqSvc.chat(message);`;

// Nouveau: groq.chat avec le contexte de conversation
const newGroq = `if (isSimpleMessage(message)) {
      console.log('[ANA-DIRECT] Simple → Groq');
      const groqSvc = require('../services/groq-service.cjs');
      groqSvc.initialize();

      // Construire l'historique de conversation pour Groq
      const conversationHistory = [];
      if (options.memoryContext) {
        // Parser le contexte pour extraire les messages précédents
        const lines = options.memoryContext.split('\\n');
        for (const line of lines) {
          if (line.startsWith('Alain:')) {
            conversationHistory.push({ role: 'user', content: line.replace('Alain:', '').trim() });
          } else if (line.startsWith('Ana')) {
            conversationHistory.push({ role: 'assistant', content: line.replace(/Ana[^:]*:/, '').trim() });
          }
        }
        console.log('[ANA-DIRECT] Contexte conversation:', conversationHistory.length, 'messages');
      }

      const gr = await groqSvc.chat(message, { conversationHistory });`;

if (content.includes(oldGroq)) {
  content = content.replace(oldGroq, newGroq);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✓ Groq context patch appliqué');
} else {
  console.log('Pattern non trouvé');
  // Debug
  const idx = content.indexOf('isSimpleMessage(message)');
  if (idx > -1) {
    console.log('Code actuel:', content.substring(idx, idx + 300));
  }
}
