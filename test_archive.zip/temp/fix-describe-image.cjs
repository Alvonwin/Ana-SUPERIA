/**
 * Fix describe_image tool definition
 * Problem: LLM invents URLs instead of using user's exact local path
 * Solution: Make description very explicit about using EXACT path
 */

const fs = require('fs');

const filePath = 'E:/ANA/server/agents/tool-agent.cjs';

// Read file
let content = fs.readFileSync(filePath, 'utf8');

// Create backup
const backupPath = filePath + '.backup_vision_fix_' + Date.now();
fs.writeFileSync(backupPath, content, 'utf8');
console.log('Backup créé:', backupPath);

// Old definition
const oldDef = `  // ============ VISION TOOLS - Phase 3.2 ANA CODE ============
  {
    type: 'function',
    function: {
      name: 'describe_image',
      description: 'Analyser et decrire une image en detail.',
      parameters: {
        type: 'object',
        properties: {
          image_path: { type: 'string', description: 'Chemin vers l\\'image a analyser' },
          image_base64: { type: 'string', description: 'Image en base64 (alternative a image_path)' },
          prompt: { type: 'string', description: 'Question ou instruction specifique pour l\\'analyse' }
        },
        required: []
      }
    }
  },`;

// New definition with explicit instructions
const newDef = `  // ============ VISION TOOLS - Phase 3.2 ANA CODE ============
  // FIX 2025-12-17: Description explicite pour forcer utilisation chemin exact
  {
    type: 'function',
    function: {
      name: 'describe_image',
      description: 'Analyser une image LOCALE sur le PC. REGLE CRITIQUE: Quand l\\'utilisateur fournit un chemin comme "C:\\\\Users\\\\...\\\\image.jpg", tu DOIS utiliser CE CHEMIN EXACT dans image_path. NE JAMAIS inventer de chemin ni d\\'URL. Copie EXACTEMENT le chemin fourni.',
      parameters: {
        type: 'object',
        properties: {
          image_path: { type: 'string', description: 'Chemin EXACT vers l\\'image locale fourni par l\\'utilisateur. OBLIGATOIRE. Ne pas modifier ni inventer. Exemple: C:\\\\Users\\\\nom\\\\Photos\\\\315.jpg' },
          image_base64: { type: 'string', description: 'Image en base64 (uniquement pour images web ou captures)' },
          prompt: { type: 'string', description: 'Question specifique pour l\\'analyse (optionnel)' }
        },
        required: ['image_path']
      }
    }
  },`;

if (content.includes(oldDef)) {
  content = content.replace(oldDef, newDef);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✅ describe_image definition updated!');
  console.log('Changed:');
  console.log('- Description now explicitly requires EXACT user path');
  console.log('- image_path is now REQUIRED');
  console.log('- Added warning about NOT inventing URLs');
} else {
  console.log('⚠️ Pattern not found. Searching for describe_image...');

  // Try to find and show what's there
  const match = content.match(/describe_image[\s\S]{0,500}/);
  if (match) {
    console.log('Found describe_image in file, but definition differs:');
    console.log(match[0].substring(0, 300) + '...');
  }
}
