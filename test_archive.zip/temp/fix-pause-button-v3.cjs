/**
 * FIX 2025-12-18: Vrai bouton PAUSE (pas stop)
 * - Premier clic: pause à la position actuelle
 * - Deuxième clic: reprend là où c'était
 */
const fs = require('fs');

const file = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(file, 'utf8');

// Trouver et remplacer handlePlayPause
const oldPattern = /const handlePlayPause = async \(messageId, text\) => \{[\s\S]*?^\s{2}\};/m;

const newFunction = `const handlePlayPause = async (messageId, text) => {
    // FIX 2025-12-18: Vrai PAUSE/RESUME (pas stop)

    // Cas 1: Audio edge-tts en cours de lecture → PAUSE
    if (currentAudioRef.current && !currentAudioRef.current.paused && playingAudio === messageId) {
      currentAudioRef.current.pause();
      console.log('⏸️ Audio mis en pause');
      return;
    }

    // Cas 2: Audio edge-tts en pause → REPRENDRE
    if (currentAudioRef.current && currentAudioRef.current.paused && playingAudio === messageId) {
      currentAudioRef.current.play();
      console.log('▶️ Audio repris');
      return;
    }

    // Cas 3: Clic sur un AUTRE message pendant lecture → arrêter l'ancien, démarrer le nouveau
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if (window.speechSynthesis) window.speechSynthesis.cancel();

    // Cas 4: Pas de lecture en cours → démarrer nouvelle lecture
    const onEnd = () => {
      setPlayingAudio(null);
      currentAudioRef.current = null;
      console.log('✅ Lecture audio terminée');
    };

    const onError = (err) => {
      console.error('❌ Erreur TTS:', err);
      setPlayingAudio(null);
      currentAudioRef.current = null;
      addSystemMessage('❌ Erreur synthèse vocale', 'error');
    };

    // Utiliser Sylvie (edge-tts) ou voix navigateur
    if (selectedVoice?.name === SYLVIE_VOICE || !selectedVoice) {
      setPlayingAudio(messageId);
      await speakWithEdgeTTS(text, onEnd, onError);
    } else if (window.speechSynthesis) {
      try {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'fr-FR';
        utterance.rate = playbackRate;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        if (selectedVoice) utterance.voice = selectedVoice;
        utterance.onend = onEnd;
        utterance.onerror = (event) => onError(event.error);
        window.speechSynthesis.speak(utterance);
        setPlayingAudio(messageId);
      } catch (error) {
        onError(error);
      }
    } else {
      addSystemMessage('❌ Synthèse vocale non supportée', 'error');
    }
  };`;

if (oldPattern.test(content)) {
  content = content.replace(oldPattern, newFunction);
  fs.writeFileSync(file, content, 'utf8');
  console.log('✅ handlePlayPause remplacé par version PAUSE/RESUME');
  console.log('');
  console.log('Comportement:');
  console.log('- 1er clic: Pause à la position actuelle');
  console.log('- 2e clic: Reprend là où c\'était');
  console.log('- Clic sur autre message: Arrête et démarre le nouveau');
} else {
  console.log('⚠️ Pattern non trouvé, essai alternatif...');

  // Essayer de trouver juste le début
  if (content.includes('const handlePlayPause = async (messageId, text)')) {
    // Trouver la position de début
    const startIdx = content.indexOf('const handlePlayPause = async (messageId, text)');
    // Chercher la fin (la fonction suivante ou const suivant)
    const afterStart = content.substring(startIdx);
    const endMatch = afterStart.match(/\n  const handle[A-Z]/);

    if (endMatch) {
      const endIdx = startIdx + endMatch.index;
      const oldFunc = content.substring(startIdx, endIdx);
      content = content.substring(0, startIdx) + newFunction + '\n\n  ' + content.substring(endIdx + 3);
      fs.writeFileSync(file, content, 'utf8');
      console.log('✅ handlePlayPause remplacé (méthode alternative)');
    } else {
      console.log('❌ Impossible de trouver la fin de la fonction');
    }
  } else {
    console.log('❌ Fonction handlePlayPause non trouvée');
  }
}

console.log('\nRedémarre le frontend pour appliquer.');
