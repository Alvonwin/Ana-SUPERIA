// Patch ana-core.cjs pour ajouter extraction de tool patterns
const fs = require('fs');
const path = 'E:/ANA/server/ana-core.cjs';

let content = fs.readFileSync(path, 'utf8');

// Pattern à remplacer (flux tools)
const oldTools = `          const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: req.body.sessionId || 'chat_main',
            context: memoryContext
          });
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
        }
        else if (expertType === 'research') {`;

const newTools = `          const toolResult = await toolAgent.runToolAgentV2(message, {
            sessionId: req.body.sessionId || 'chat_main',
            context: memoryContext
          });
          // FIX 2025-12-17: Extraire tool patterns pour apprentissage
          const toolsUsed = toolResult?.stats?.toolCallCounts || {};
          if (Object.keys(toolsUsed).length > 0) {
            skillLearner.extractSkillsFromConversation({
              userMessage: message,
              anaResponse: toolResult.answer || '',
              model: toolResult.model || 'tool-agent',
              success: toolResult.success,
              toolsUsed: toolsUsed
            }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
          }
          return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur outil';
        }
        else if (expertType === 'research') {`;

if (content.includes(oldTools)) {
  content = content.replace(oldTools, newTools);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✅ Patch 1 appliqué (flux tools)');
} else {
  console.log('⚠️ Pattern tools non trouvé ou déjà patché');
}

// Pattern à remplacer (flux research)
const oldResearch = `            const toolResult = await toolAgent.runToolAgentV2(message, {
              // FIX 2025-12-15: Pas de model hardcodé - orchestrateur décide
              sessionId: req.body.sessionId || 'chat_main',
              context: memoryContext
            });
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';`;

const newResearch = `            const toolResult = await toolAgent.runToolAgentV2(message, {
              // FIX 2025-12-15: Pas de model hardcodé - orchestrateur décide
              sessionId: req.body.sessionId || 'chat_main',
              context: memoryContext
            });
            // FIX 2025-12-17: Extraire tool patterns pour apprentissage
            const toolsUsedResearch = toolResult?.stats?.toolCallCounts || {};
            if (Object.keys(toolsUsedResearch).length > 0) {
              skillLearner.extractSkillsFromConversation({
                userMessage: message,
                anaResponse: toolResult.answer || '',
                model: toolResult.model || 'tool-agent',
                success: toolResult.success,
                toolsUsed: toolsUsedResearch
              }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
            }
            return toolResult.success ? toolResult.answer : toolResult.error || 'Erreur recherche';`;

content = fs.readFileSync(path, 'utf8');
if (content.includes(oldResearch)) {
  content = content.replace(oldResearch, newResearch);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✅ Patch 2 appliqué (flux research)');
} else {
  console.log('⚠️ Pattern research non trouvé ou déjà patché');
}

console.log('Done');
