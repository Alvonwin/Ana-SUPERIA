// Ajouter les méthodes pour tool patterns dans skill-learner.cjs
const fs = require('fs');
const path = 'E:/ANA/server/intelligence/skill-learner.cjs';

let content = fs.readFileSync(path, 'utf8');

// Vérifier si déjà présent
if (content.includes('async extractToolPattern(')) {
  console.log('Méthodes déjà présentes');
  process.exit(0);
}

// Les nouvelles méthodes
const newMethods = `

  // ========================================================
  // FIX 2025-12-17: Methodes pour apprentissage tool patterns
  // ========================================================

  /**
   * Utilise semantic-router pour classifier le type de tache
   */
  async getTaskType(message) {
    try {
      const semanticRouter = require('./semantic-router.cjs');
      if (!semanticRouter.initialized) {
        await semanticRouter.initialize();
      }
      const result = await semanticRouter.route(message);
      return result.taskType || 'conversation';
    } catch (e) {
      console.log('[SkillLearner] getTaskType fallback:', e.message);
      return 'conversation';
    }
  }

  /**
   * Extrait et stocke les patterns d'utilisation d'outils
   */
  async extractToolPattern(userMessage, toolsUsed, success) {
    const taskType = await this.getTaskType(userMessage);

    for (const [toolName, count] of Object.entries(toolsUsed)) {
      const pattern = {
        id: 'tp_' + Date.now() + '_' + toolName,
        type: 'tool_pattern',
        name: toolName + '_for_' + taskType,
        description: 'Outil ' + toolName + ' efficace pour taches ' + taskType,
        toolName: toolName,
        taskType: taskType,
        confidence: success ? 'high' : 'low',
        importance: 7,
        occurrences: 1,
        successCount: success ? 1 : 0,
        failureCount: success ? 0 : 1,
        learnedAt: new Date().toISOString(),
        lastSeen: new Date().toISOString()
      };

      // Verifier si pattern similaire existe
      const existing = this.findSimilarToolPattern(toolName, taskType);
      if (existing) {
        existing.occurrences++;
        if (success) existing.successCount = (existing.successCount || 0) + 1;
        else existing.failureCount = (existing.failureCount || 0) + 1;
        existing.lastSeen = new Date().toISOString();
        // Ajuster confidence base sur taux de succes
        const rate = existing.successCount / (existing.successCount + existing.failureCount);
        existing.confidence = rate > 0.8 ? 'high' : rate > 0.5 ? 'medium' : 'low';
      } else {
        if (!this.skills.skills) this.skills.skills = [];
        this.skills.skills.push(pattern);
      }
    }

    this.saveSkills();
    console.log('[SkillLearner] Pattern appris: ' + Object.keys(toolsUsed).join(', ') + ' pour ' + taskType);
  }

  /**
   * Trouve un tool pattern similaire existant
   */
  findSimilarToolPattern(toolName, taskType) {
    if (!this.skills || !this.skills.skills) return null;
    return this.skills.skills.find(s =>
      s.type === 'tool_pattern' &&
      s.toolName === toolName &&
      s.taskType === taskType
    );
  }

  /**
   * Retourne les outils les plus efficaces pour un taskType
   */
  getRecommendedTools(taskType, limit = 5) {
    if (!this.skills || !this.skills.skills) return [];

    return this.skills.skills
      .filter(s => s.type === 'tool_pattern' && s.taskType === taskType)
      .map(s => ({
        ...s,
        successRate: s.successCount / ((s.successCount || 0) + (s.failureCount || 0) || 1)
      }))
      .sort((a, b) => {
        // Priorite 1: taux de succes
        if (b.successRate !== a.successRate) return b.successRate - a.successRate;
        // Priorite 2: nombre d'occurrences (experience)
        return (b.occurrences || 0) - (a.occurrences || 0);
      })
      .slice(0, limit);
  }
`;

// Trouver la fin de la classe et insérer avant
// Pattern: chercher "}\n\nmodule.exports" ou "}\r\nmodule.exports"
const endClassRegex = /(\n}\r?\n\r?\nmodule\.exports = new SkillLearner\(\);)/;

if (endClassRegex.test(content)) {
  content = content.replace(endClassRegex, newMethods + '\n}\n\nmodule.exports = new SkillLearner();');
  fs.writeFileSync(path, content, 'utf8');
  console.log('✅ Nouvelles méthodes ajoutées à skill-learner.cjs');
} else {
  console.log('⚠️ Pattern de fin de classe non trouvé');
  // Debug: montrer les derniers caractères
  console.log('Derniers 100 chars:', JSON.stringify(content.slice(-100)));
}
