const fs = require('fs');
let content = fs.readFileSync('E:/ANA/server/ana-core.cjs', 'utf8');

// Fix 1: Tools path
content = content.replace(
  /const filteredAnswer = forceTutoiement\(result\.answer\);/g,
  'let filteredAnswer = forceTutoiement(result.answer);\n            filteredAnswer = spellChecker.correctText(filteredAnswer);'
);

// Fix 2: Groq path
content = content.replace(
  /const filteredGroq = forceTutoiement\(groqResult\.response\);/g,
  'let filteredGroq = forceTutoiement(groqResult.response);\n            filteredGroq = spellChecker.correctText(filteredGroq);'
);

// Fix 3: Cerebras fallback path
content = content.replace(
  /const filteredCerebras = forceTutoiement\(cerebrasResult\.response\);/g,
  'let filteredCerebras = forceTutoiement(cerebrasResult.response);\n            filteredCerebras = spellChecker.correctText(filteredCerebras);'
);

fs.writeFileSync('E:/ANA/server/ana-core.cjs', content, 'utf8');
console.log('Done');
