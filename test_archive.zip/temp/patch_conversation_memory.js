// Patch ana-core.cjs pour inclure le buffer de session dans le WebSocket
const fs = require('fs');
const path = 'E:/ANA/server/ana-core.cjs';

let content = fs.readFileSync(path, 'utf8');

// Ancien code: utilise seulement getContext()
const oldCode = `// Récupérer contexte mémoire
        const memoryContext = memory.getContext();
        const fullPrompt = memoryContext ? \`\${memoryContext}\\n\\nQuestion: \${message}\` : message;`;

// Nouveau code: utilise AUSSI getSessionContext() pour la conversation récente
const newCode = `// Récupérer contexte mémoire + conversation récente
        const sessionContext = memory.getSessionContext(); // 20 derniers messages
        const fileContext = memory.getContext(); // Mémoire long terme
        const memoryContext = sessionContext || fileContext;
        console.log('[WS-MEMORY] Session:', sessionContext ? sessionContext.length + ' chars' : 'vide');
        const fullPrompt = memoryContext ? \`\${memoryContext}\\n\\nQuestion: \${message}\` : message;`;

if (content.includes(oldCode)) {
  content = content.replace(oldCode, newCode);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✓ Patch conversation memory appliqué');
} else {
  console.log('Pattern non trouvé - vérification...');
  if (content.includes('getSessionContext')) {
    console.log('getSessionContext existe dans le fichier');
  }
  if (content.includes('// Récupérer contexte mémoire')) {
    console.log('Commentaire trouvé');
  }
}
