/**
 * FIX 2025-12-18: Corriger le bouton Pause pour edge-tts
 * Problème: L'objet Audio n'était pas stocké, impossible à arrêter
 */
const fs = require('fs');

const file = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(file, 'utf8');

// Backup
const backupFile = file + '.backup_pause_' + Date.now();
fs.writeFileSync(backupFile, content, 'utf8');
console.log('✅ Backup créé:', backupFile);

let changes = 0;

// === FIX 1: Ajouter le ref pour l'audio ===
const pattern1_old = `  const messagesEndRef = useRef(null);
  const voiceLoopRef = useRef(null);
  const fileInputRef = useRef(null);

  // Helper: Convert file to base64`;

const pattern1_new = `  const messagesEndRef = useRef(null);
  const voiceLoopRef = useRef(null);
  const fileInputRef = useRef(null);
  const currentAudioRef = useRef(null); // FIX 2025-12-18: Stocker audio edge-tts pour pause

  // Helper: Convert file to base64`;

if (content.includes(pattern1_old)) {
  content = content.replace(pattern1_old, pattern1_new);
  changes++;
  console.log('✅ FIX 1: Ref currentAudioRef ajouté');
} else if (content.includes('currentAudioRef')) {
  console.log('ℹ️ FIX 1: Ref déjà présent');
} else {
  console.log('⚠️ FIX 1: Pattern non trouvé');
}

// === FIX 2: Modifier handlePlayPause pour arrêter l'audio ===
const pattern2_old = `  const handlePlayPause = async (messageId, text) => {
    // Si déjà en lecture, arrêter
    if (playingAudio === messageId) {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setPlayingAudio(null);
      return;
    }`;

const pattern2_new = `  const handlePlayPause = async (messageId, text) => {
    // Si déjà en lecture, arrêter
    if (playingAudio === messageId) {
      // FIX 2025-12-18: Arrêter l'audio edge-tts
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setPlayingAudio(null);
      return;
    }`;

if (content.includes(pattern2_old)) {
  content = content.replace(pattern2_old, pattern2_new);
  changes++;
  console.log('✅ FIX 2: handlePlayPause modifié pour arrêter audio');
} else if (content.includes('currentAudioRef.current.pause()')) {
  console.log('ℹ️ FIX 2: Déjà corrigé');
} else {
  console.log('⚠️ FIX 2: Pattern non trouvé');
}

// === FIX 3: Modifier speakWithEdgeTTS pour stocker l'audio ===
const pattern3_old = `      audio.play();
      return audio;`;

const pattern3_new = `      currentAudioRef.current = audio; // FIX 2025-12-18: Stocker pour pause
      audio.play();
      return audio;`;

if (content.includes(pattern3_old) && !content.includes('currentAudioRef.current = audio')) {
  content = content.replace(pattern3_old, pattern3_new);
  changes++;
  console.log('✅ FIX 3: speakWithEdgeTTS stocke maintenant l\'audio');
} else if (content.includes('currentAudioRef.current = audio')) {
  console.log('ℹ️ FIX 3: Déjà corrigé');
} else {
  console.log('⚠️ FIX 3: Pattern non trouvé');
}

// Écrire si changements
if (changes > 0) {
  fs.writeFileSync(file, content, 'utf8');
  console.log(`\n✅ ${changes} fix(es) appliqué(s) à ChatPage.jsx`);
} else {
  console.log('\nℹ️ Aucun changement nécessaire');
}

console.log('\nRedémarre Ana (frontend) pour appliquer.');
