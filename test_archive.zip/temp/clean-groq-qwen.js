const fs = require('fs');

// LogsPage.jsx
let logs = fs.readFileSync('E:/ANA/ana-interface/src/pages/LogsPage.jsx', 'utf8');
logs = logs.replace(/, Qwen: \$\{data\.llm_usage\?\.qwen \|\| 0\}/g, '');
fs.writeFileSync('E:/ANA/ana-interface/src/pages/LogsPage.jsx', logs, 'utf8');
console.log('LogsPage done');

// ManualPage.jsx
let manual = fs.readFileSync('E:/ANA/ana-interface/src/pages/ManualPage.jsx', 'utf8');
manual = manual.replace(/, Qwen/g, '');
manual = manual.replace(/\['GROQ','Cloud','Llama, Mixtral'\],/g, '');
fs.writeFileSync('E:/ANA/ana-interface/src/pages/ManualPage.jsx', manual, 'utf8');
console.log('ManualPage done');

// VoicePage.jsx
let voice = fs.readFileSync('E:/ANA/ana-interface/src/pages/VoicePage.jsx', 'utf8');
voice = voice.replace(/\{ id: 'qwen2\.5:7b', name: 'Qwen 2\.5 7B' \},?\n?\s*/g, '');
fs.writeFileSync('E:/ANA/ana-interface/src/pages/VoicePage.jsx', voice, 'utf8');
console.log('VoicePage done');

// BrainsPage.jsx
let brains = fs.readFileSync('E:/ANA/ana-interface/src/pages/BrainsPage.jsx', 'utf8');
brains = brains.replace(/case 'groq': return '🚀';\n\s*/g, '');
brains = brains.replace(/case 'groq': return '#f97316';\n\s*/g, '');
fs.writeFileSync('E:/ANA/ana-interface/src/pages/BrainsPage.jsx', brains, 'utf8');
console.log('BrainsPage done');

console.log('All done');
