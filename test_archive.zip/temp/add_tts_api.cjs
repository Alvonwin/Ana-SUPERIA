const fs = require('fs');
const path = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(path, 'utf8');

const marker = '// ================== SPELL CHECK API (13-Dec-2025) ==================';

const ttsCode = `// ================== TTS API (16-Dec-2025) ==================
// Synthese vocale avec voix quebecoise
const ttsService = require('./services/tts-service.cjs');

// POST - Synthetiser du texte en audio
app.post('/api/tts/synthesize', async (req, res) => {
  try {
    const { text } = req.body;

    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Le champ text est requis et doit etre une chaine non vide'
      });
    }

    const audioPath = await ttsService.synthesize(text.trim());

    if (audioPath) {
      res.sendFile(audioPath);
    } else {
      res.status(500).json({
        success: false,
        error: 'Erreur de synthese vocale'
      });
    }
  } catch (error) {
    console.error('[TTS API] Erreur:', error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// GET - Statistiques TTS
app.get('/api/tts/stats', (req, res) => {
  res.json({
    success: true,
    stats: ttsService.getStats()
  });
});

// GET - Lister les voix disponibles
app.get('/api/tts/voices', async (req, res) => {
  try {
    const voices = await ttsService.listVoices();
    res.json({
      success: true,
      voices,
      current: ttsService.voice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// POST - Changer la voix
app.post('/api/tts/voice', (req, res) => {
  try {
    const { voice } = req.body;

    if (!voice || typeof voice !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Le champ voice est requis'
      });
    }

    ttsService.setVoice(voice);
    res.json({
      success: true,
      voice: ttsService.voice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

`;

if (content.includes('/api/tts/synthesize')) {
  console.log('TTS API already present');
} else if (content.includes(marker)) {
  content = content.replace(marker, ttsCode + marker);
  fs.writeFileSync(path, content, 'utf8');
  console.log('TTS API added successfully');
} else {
  console.log('Marker not found');
}
