/**
 * Fix llama_vision_handler.cjs to better handle paths
 * - Detect and reject URLs (since we only handle local files)
 * - Check if file exists before reading
 * - Better error messages
 */

const fs = require('fs');
const path = require('path');

const filePath = 'E:/ANA/intelligence/vision/llama_vision_handler.cjs';

// Read file
let content = fs.readFileSync(filePath, 'utf8');

// Backup
const backupPath = filePath + '.backup_' + Date.now();
fs.writeFileSync(backupPath, content, 'utf8');
console.log('Backup:', backupPath);

// Old imageToBase64 function
const oldFunc = `  imageToBase64(imagePath) {
    const ext = path.extname(imagePath).toLowerCase();
    if (!this.supportedFormats.includes(ext)) {
      throw new Error(\`Unsupported image format: \${ext}. Supported: \${this.supportedFormats.join(', ')}\`);
    }

    const imageBuffer = fs.readFileSync(imagePath);
    return imageBuffer.toString('base64');
  }`;

// New improved function with better validation
const newFunc = `  imageToBase64(imagePath) {
    // FIX 2025-12-17: Better path validation

    // 1. Reject URLs - we only handle LOCAL files
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      throw new Error(\`Cette fonction ne supporte que les images LOCALES. "\${imagePath}" est une URL. Utilise un chemin local comme "C:\\\\Users\\\\...\\\\image.jpg"\`);
    }

    // 2. Normalize Windows path (convert forward slashes if needed)
    let normalizedPath = imagePath.replace(/\\//g, path.sep);

    // 3. Check if file exists
    if (!fs.existsSync(normalizedPath)) {
      throw new Error(\`Fichier image introuvable: "\${normalizedPath}". Verifie que le chemin est correct et que le fichier existe.\`);
    }

    // 4. Check format
    const ext = path.extname(normalizedPath).toLowerCase();
    if (!this.supportedFormats.includes(ext)) {
      throw new Error(\`Format image non supporte: \${ext}. Formats supportes: \${this.supportedFormats.join(', ')}\`);
    }

    // 5. Read and convert to base64
    const imageBuffer = fs.readFileSync(normalizedPath);
    this.log(\`Image loaded: \${normalizedPath} (\${Math.round(imageBuffer.length / 1024)} KB)\`);
    return imageBuffer.toString('base64');
  }`;

if (content.includes(oldFunc)) {
  content = content.replace(oldFunc, newFunc);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✅ imageToBase64 improved!');
  console.log('Changes:');
  console.log('- URLs are now rejected with clear error message');
  console.log('- File existence check before reading');
  console.log('- Path normalization for Windows');
  console.log('- Better error messages in French');
} else {
  console.log('⚠️ Pattern not found exactly. Trying alternative...');

  // Try finding the function
  if (content.includes('imageToBase64(imagePath)')) {
    console.log('Function found but format differs.');
    console.log('Manual update may be needed.');
  }
}
