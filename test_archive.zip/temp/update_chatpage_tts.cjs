const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// 1. Ajouter l'import du ttsService après les autres imports
const importMarker = "import './ChatPage.css';";
const ttsImport = `import './ChatPage.css';
import ttsService from '../utils/ttsService';`;

if (!content.includes("import ttsService")) {
  content = content.replace(importMarker, ttsImport);
  console.log('✓ Import ttsService ajouté');
}

// 2. Remplacer le bloc auto-speak (lignes ~405-432)
const oldAutoSpeak = `// Déclencher l'audio après un délai pour laisser React mettre à jour le state
      setTimeout(() => {
        if (finalText && window.speechSynthesis) {
          // PAUSE la reconnaissance vocale pendant le TTS
          if (voiceLoopRef.current) {
            voiceLoopRef.current.pause();
          }

          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(finalText);
          utterance.lang = 'fr-FR';
          utterance.rate = playbackRate;
          if (selectedVoice) utterance.voice = selectedVoice;

          // Callback quand Ana finit de parler
          utterance.onend = () => {
            setPlayingAudio(null);
            console.log('✅ TTS terminé');
            // RESUME la reconnaissance vocale après le TTS
            if (voiceLoopRef.current) {
              voiceLoopRef.current.resume();
            }
          };

          window.speechSynthesis.speak(utterance);
          setPlayingAudio(finalMessageId);
        }
      }, 100);`;

const newAutoSpeak = `// Déclencher l'audio après un délai pour laisser React mettre à jour le state
      setTimeout(async () => {
        if (finalText) {
          // PAUSE la reconnaissance vocale pendant le TTS
          if (voiceLoopRef.current) {
            voiceLoopRef.current.pause();
          }

          setPlayingAudio(finalMessageId);

          await ttsService.speak(finalText, {
            onEnd: () => {
              setPlayingAudio(null);
              console.log('✅ Sylvie a fini de parler');
              // RESUME la reconnaissance vocale après le TTS
              if (voiceLoopRef.current) {
                voiceLoopRef.current.resume();
              }
            },
            onError: (err) => {
              console.error('❌ Erreur TTS:', err);
              setPlayingAudio(null);
              if (voiceLoopRef.current) {
                voiceLoopRef.current.resume();
              }
            }
          });
        }
      }, 100);`;

if (content.includes(oldAutoSpeak)) {
  content = content.replace(oldAutoSpeak, newAutoSpeak);
  console.log('✓ Auto-speak remplacé par ttsService');
} else {
  console.log('⚠ Auto-speak non trouvé (peut-être déjà modifié)');
}

// 3. Remplacer handlePlayPause
const oldPlayPause = `const handlePlayPause = (messageId, text) => {
    // Browser compatibility check
    if (!window.speechSynthesis) {
      addSystemMessage('❌ Synthèse vocale non supportée par ce navigateur', 'error');
      return;
    }

    if (playingAudio === messageId) {
      // Stop audio proprement
      window.speechSynthesis.cancel();
      setPlayingAudio(null);
      return;
    }

    // Cancel toute lecture en cours
    window.speechSynthesis.cancel();

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'fr-FR';
      utterance.rate = playbackRate;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      // Use selected voice if available
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }

      // Event: Démarrage lecture
      utterance.onstart = () => {
        console.log('🔊 Lecture audio démarrée');
      };

      // Event: Fin lecture
      utterance.onend = () => {
        setPlayingAudio(null);
        console.log('✅ Lecture audio terminée');
      };

      // Event: Erreur
      utterance.onerror = (event) => {
        console.error('❌ Erreur synthèse vocale:', event.error);
        setPlayingAudio(null);

        // Messages erreur utilisateur
        const errorMessages = {
          'canceled': 'Lecture annulée',
          'interrupted': 'Lecture interrompue',
          'audio-busy': 'Audio occupé',
          'audio-hardware': 'Problème matériel audio',
          'network': 'Erreur réseau',
          'synthesis-unavailable': 'Synthèse vocale indisponible',
          'synthesis-failed': 'Échec synthèse vocale',
          'language-unavailable': 'Langue non disponible',
          'voice-unavailable': 'Voix non disponible',
          'text-too-long': 'Texte trop long',
          'invalid-argument': 'Argument invalide',
          'not-allowed': 'Lecture non autorisée'
        };

        const userMessage = errorMessages[event.error] || \`Erreur: \${event.error}\`;
        addSystemMessage(\`🔊 \${userMessage}\`, 'error');
      };

      // Démarrer lecture
      window.speechSynthesis.speak(utterance);
      setPlayingAudio(messageId);

    } catch (error) {
      console.error('❌ Exception synthèse vocale:', error);
      addSystemMessage('❌ Erreur lors du démarrage de la lecture audio', 'error');
      setPlayingAudio(null);
    }
  };`;

const newPlayPause = `const handlePlayPause = async (messageId, text) => {
    if (playingAudio === messageId) {
      // Stop audio
      ttsService.stop();
      setPlayingAudio(null);
      return;
    }

    // Arrêter toute lecture en cours
    ttsService.stop();
    setPlayingAudio(messageId);

    try {
      await ttsService.speak(text, {
        onStart: () => {
          console.log('🔊 Sylvie parle...');
        },
        onEnd: () => {
          setPlayingAudio(null);
          console.log('✅ Lecture terminée');
        },
        onError: (error) => {
          console.error('❌ Erreur TTS:', error);
          setPlayingAudio(null);
          addSystemMessage('❌ Erreur synthèse vocale', 'error');
        }
      });
    } catch (error) {
      console.error('❌ Exception TTS:', error);
      addSystemMessage('❌ Erreur lors de la lecture audio', 'error');
      setPlayingAudio(null);
    }
  };`;

if (content.includes(oldPlayPause)) {
  content = content.replace(oldPlayPause, newPlayPause);
  console.log('✓ handlePlayPause remplacé par ttsService');
} else {
  console.log('⚠ handlePlayPause non trouvé (peut-être déjà modifié)');
}

// Sauvegarder
fs.writeFileSync(path, content, 'utf8');
console.log('✓ ChatPage.jsx mis à jour avec la voix de Sylvie!');
