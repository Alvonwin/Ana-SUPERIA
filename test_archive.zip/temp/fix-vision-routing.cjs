/**
 * Fix vision routing in semantic-router.cjs
 */
const fs = require('fs');

const path = 'E:/ANA/server/intelligence/semantic-router.cjs';
let content = fs.readFileSync(path, 'utf8');

// Backup
fs.writeFileSync(path + '.backup_vision_' + Date.now(), content, 'utf8');
console.log('Backup created');

const oldCode = `  async route(message, context = {}) {
    this.stats.totalRoutes++;
    if (context.hasImage || context.images?.length > 0) {
      this.updateStats('VISION');
      return {
        model: TASK_TYPES.VISION.preferredModel,
        taskType: 'vision',
        reason: 'Image detected in context',
        confidence: 1.0,
        method: 'context_override'
      };
    }

    const msgLower = message.toLowerCase();`;

const newCode = `  async route(message, context = {}) {
    this.stats.totalRoutes++;
    const msgLower = message.toLowerCase();

    // FIX 2025-12-18: Detecter les demandes de vision meme sans image uploadee
    // L'utilisateur peut donner un chemin d'image dans son message
    const hasImagePath = /\\.(jpg|jpeg|png|gif|webp|bmp)\\b/i.test(message);
    const visionKeywords = ['regarde', 'vois', 'cette image', "l'image", 'photo', 'decris', 'describe', 'analyser'];
    const isVisionRequest = hasImagePath || visionKeywords.some(kw => msgLower.includes(kw));

    if (context.hasImage || context.images?.length > 0 || isVisionRequest) {
      this.updateStats('VISION');
      console.log('[SemanticRouter] 👁️ VISION detected:', hasImagePath ? 'image path in message' : 'vision keywords');
      return {
        model: TASK_TYPES.VISION.preferredModel,
        taskType: 'vision',
        reason: hasImagePath ? 'Image path in message' : 'Vision keywords detected',
        confidence: 1.0,
        method: 'vision_detection'
      };
    }`;

if (content.includes(oldCode)) {
  content = content.replace(oldCode, newCode);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✅ Vision detection amelioree dans semantic-router.cjs');
} else {
  console.log('⚠️ Pattern non trouve exactement');
  // Essayons de trouver où est le code
  if (content.includes('async route(message, context = {})')) {
    console.log('   La fonction route existe');
  }
  if (content.includes('context.hasImage')) {
    console.log('   context.hasImage existe');
  }
}
