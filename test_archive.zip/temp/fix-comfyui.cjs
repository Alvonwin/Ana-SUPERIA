const fs = require('fs');
const content = `.\\python_embeded\\python.exe -s ComfyUI\\main.py --windows-standalone-build --enable-cors-header "*"
echo If you see this and ComfyUI did not start try updating your Nvidia Drivers to the latest.
`;
fs.writeFileSync('E:/AI_Tools/ComfyUI/run_nvidia_gpu.bat', content);
console.log('Fixed!');
console.log('Content:');
console.log(fs.readFileSync('E:/AI_Tools/ComfyUI/run_nvidia_gpu.bat', 'utf8'));
