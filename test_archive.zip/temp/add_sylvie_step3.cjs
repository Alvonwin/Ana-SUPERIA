const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// 3. Modifier le dropdown pour ajouter Sylvie en premier
const oldDropdown = `{/* Voice selection */}
                  {availableVoices.length > 0 && (
                    <select
                      className="voice-select"
                      value={selectedVoice?.name || ''}
                      onChange={(e) => handleVoiceChange(e.target.value)}
                      title="Sélectionner une voix"
                    >
                      {availableVoices.map(voice => (
                        <option key={voice.name} value={voice.name}>
                          {voice.name.split(' ')[0]}
                        </option>
                      ))}
                    </select>
                  )}`;

const newDropdown = `{/* Voice selection */}
                  <select
                    className="voice-select"
                    value={selectedVoice?.name || SYLVIE_VOICE}
                    onChange={(e) => handleVoiceChange(e.target.value)}
                    title="Sélectionner une voix"
                  >
                    <option key="sylvie-quebec" value={SYLVIE_VOICE}>
                      Sylvie (Québec)
                    </option>
                    {availableVoices.map(voice => (
                      <option key={voice.name} value={voice.name}>
                        {voice.name.split(' ')[0]}
                      </option>
                    ))}
                  </select>`;

if (content.includes(oldDropdown)) {
  content = content.replace(oldDropdown, newDropdown);
  console.log('✓ Dropdown modifié avec Sylvie');
} else {
  console.log('⚠ Pattern dropdown non trouvé');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
