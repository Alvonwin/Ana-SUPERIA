// Patch ana-direct.cjs pour exclure les messages avec mots-clés tools
const fs = require('fs');
const path = 'E:/ANA/server/intelligence/ana-direct.cjs';

let content = fs.readFileSync(path, 'utf8');

// Remplacer isSimpleMessage
const oldFunc = `function isSimpleMessage(msg) {
  const trimmed = msg.trim();
  return SIMPLE_PATTERNS.some(p => p.test(trimmed)) || trimmed.length < 30;
}`;

const newFunc = `// Mots-clés qui NÉCESSITENT des tools (pas simple même si salutation)
const NEEDS_TOOLS_PATTERNS = [
  /heure|quelle.*heure|il est.*h/i,
  /météo|meteo|temps.*fait|température|temperature/i,
  /cherche|recherche|trouve|google/i,
  /lis|lire|ouvre|fichier|dossier/i,
  /ip.*publique|mon.*ip|adresse.*ip/i,
  /ping|dns|whois/i
];

function isSimpleMessage(msg) {
  const trimmed = msg.trim();

  // Si contient mot-clé qui nécessite tool → PAS simple
  if (NEEDS_TOOLS_PATTERNS.some(p => p.test(trimmed))) {
    console.log('[ANA-DIRECT] Message contient mot-clé tool → NOT simple');
    return false;
  }

  return SIMPLE_PATTERNS.some(p => p.test(trimmed)) || trimmed.length < 30;
}`;

if (content.includes(oldFunc)) {
  content = content.replace(oldFunc, newFunc);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✓ isSimpleMessage patché - exclusions tool ajoutées');
} else {
  console.log('✗ Pattern non trouvé - peut-être déjà patché?');
  // Vérifier si déjà patché
  if (content.includes('NEEDS_TOOLS_PATTERNS')) {
    console.log('✓ Déjà patché!');
  }
}
