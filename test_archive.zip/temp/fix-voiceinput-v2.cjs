/**
 * VoiceInput V2 - Fix arrêt automatique avec useRef
 */
const fs = require('fs');

const newContent = `import { useState, useRef, useEffect, useCallback } from 'react';
import './VoiceInput.css';
import { BACKEND_URL } from '../config.js';

async function correctSpelling(text) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/spellcheck\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await response.json();
    if (data.success && data.corrected) {
      if (data.changed) console.log('Correction:', text, '->', data.corrected);
      return data.corrected;
    }
  } catch (e) {
    console.warn('Spell check failed:', e.message);
  }
  return text;
}

async function transcribeWithWhisper(audioBlob) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/transcribe\`, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/webm' },
      body: audioBlob
    });
    const data = await response.json();
    if (data.success && data.text) {
      console.log('[Whisper] Transcription:', data.text);
      return data.text;
    } else {
      throw new Error(data.error || 'Transcription failed');
    }
  } catch (e) {
    console.error('[Whisper] Error:', e.message);
    throw e;
  }
}

function VoiceInput({ onTranscript, onAutoSubmit, disabled = false }) {
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState('Pret');
  const [isProcessing, setIsProcessing] = useState(false);

  // Refs pour eviter problemes de closure
  const isRecordingRef = useRef(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const streamRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const silenceStartRef = useRef(null);
  const animationFrameRef = useRef(null);
  const hasSpokenRef = useRef(false);

  const SILENCE_THRESHOLD = 10;
  const SILENCE_DURATION = 1500;

  const stopRecording = useCallback(() => {
    console.log('[VoiceInput] stopRecording called');
    isRecordingRef.current = false;

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }

    setIsRecording(false);
  }, []);

  const checkSilence = useCallback(() => {
    if (!isRecordingRef.current || !analyserRef.current) {
      return;
    }

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);
    const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;

    if (average > SILENCE_THRESHOLD) {
      hasSpokenRef.current = true;
      silenceStartRef.current = null;
    } else if (hasSpokenRef.current) {
      if (!silenceStartRef.current) {
        silenceStartRef.current = Date.now();
      } else if (Date.now() - silenceStartRef.current > SILENCE_DURATION) {
        console.log('[VoiceInput] Silence detecte - arret auto');
        stopRecording();
        return;
      }
    }

    if (isRecordingRef.current) {
      animationFrameRef.current = requestAnimationFrame(checkSilence);
    }
  }, [stopRecording]);

  const startRecording = async () => {
    if (disabled || isProcessing || isRecordingRef.current) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true }
      });
      streamRef.current = stream;

      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : 'audio/webm'
      });

      audioChunksRef.current = [];
      hasSpokenRef.current = false;
      silenceStartRef.current = null;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        console.log('[VoiceInput] MediaRecorder stopped');

        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
          audioContextRef.current.close();
          audioContextRef.current = null;
        }

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        console.log('[VoiceInput] Audio:', audioBlob.size, 'bytes');

        if (audioBlob.size < 1000) {
          setStatus('Audio trop court');
          return;
        }

        setStatus('Transcription...');
        setIsProcessing(true);

        try {
          const rawTranscript = await transcribeWithWhisper(audioBlob);
          if (!rawTranscript || rawTranscript.trim() === '') {
            setStatus('Aucune parole');
            setIsProcessing(false);
            return;
          }

          const transcript = await correctSpelling(rawTranscript);
          console.log('[VoiceInput] Final:', transcript);

          if (onTranscript) onTranscript(transcript);
          setStatus('OK');

          if (onAutoSubmit) {
            setTimeout(() => onAutoSubmit(transcript), 200);
          }
        } catch (error) {
          console.error('[VoiceInput] Error:', error);
          setStatus('Erreur');
        } finally {
          setIsProcessing(false);
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(100); // Chunks every 100ms

      isRecordingRef.current = true;
      setIsRecording(true);
      setStatus('Parlez...');
      console.log('[VoiceInput] Recording started');

      // Start silence detection after 500ms
      setTimeout(() => {
        if (isRecordingRef.current) {
          checkSilence();
        }
      }, 500);

    } catch (error) {
      console.error('[VoiceInput] Mic error:', error);
      setStatus('Erreur micro');
      isRecordingRef.current = false;
      setIsRecording(false);
    }
  };

  const handleClick = () => {
    if (isProcessing) return;
    if (isRecordingRef.current) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  useEffect(() => {
    return () => {
      isRecordingRef.current = false;
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, []);

  return (
    <div className="voice-input">
      <button
        className={\`voice-btn \${isRecording ? 'recording' : ''} \${isProcessing ? 'processing' : ''} \${disabled ? 'disabled' : ''}\`}
        onClick={handleClick}
        disabled={disabled || isProcessing}
        title={status}
      >
        {isProcessing ? (
          <span style={{ fontSize: '20px' }}>...</span>
        ) : isRecording ? (
          <span style={{ fontSize: '20px' }}>⏹️</span>
        ) : (
          <span style={{ fontSize: '20px' }}>🎤</span>
        )}
      </button>
      {(isRecording || isProcessing) && (
        <div className="voice-status">
          <span className="pulse-dot"></span>
          {status}
        </div>
      )}
    </div>
  );
}

export default VoiceInput;
`;

fs.writeFileSync('E:/ANA/ana-interface/src/components/VoiceInput.jsx', newContent, 'utf8');
console.log('VoiceInput.jsx V2 - fix arret auto avec useRef');
