/**
 * Fix: Fermer les fenêtres Ana correctement avec PowerShell
 * 18 Dec 2025
 */
const fs = require('fs');

const file = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
fs.writeFileSync(file + '.backup_shutdown_' + Date.now(), content, 'utf8');
console.log('✅ Backup créé');

// 1. Corriger la commande taskkill dans shutdown (utiliser PowerShell)
const oldTaskkill = 'await execPromise(`taskkill /FI "WINDOWTITLE eq ${title}*" /F /T`);';
const newTaskkill = `// PowerShell: ferme les processus dont le titre contient le texte
        await execPromise(\`powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -like '*\${title}*'} | Stop-Process -Force -ErrorAction SilentlyContinue"\`);`;

if (content.includes(oldTaskkill)) {
  content = content.replace(oldTaskkill, newTaskkill);
  console.log('✅ Shutdown: taskkill remplacé par PowerShell');
} else {
  console.log('⚠️ Pattern taskkill non trouvé');
}

// 2. Ajouter fermeture des fenêtres dans /api/restart AVANT de lancer START_ANA.bat
const oldRestart = `console.log('[RESTART] Lancement de START_ANA.bat...');

    // Lancer START_ANA.bat dans une nouvelle fenêtre (il nettoie les ports)
    spawn('cmd', ['/c', 'start', '', 'E:\\\\ANA\\\\START_ANA.bat']`;

const newRestart = `console.log('[RESTART] Fermeture des anciens terminaux Ana...');

    // FIX 2025-12-18: Fermer les fenêtres Ana AVANT de redémarrer
    const util = require('util');
    const execPromise = util.promisify(exec);
    const windowTitles = ['ChromaDB Server', 'Ana Interface Frontend', 'Ana Agents Autonomes', 'ComfyUI'];

    for (const title of windowTitles) {
      try {
        await execPromise(\`powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -like '*\${title}*'} | Stop-Process -Force -ErrorAction SilentlyContinue"\`);
        console.log(\`[RESTART] ✅ Fenêtre "\${title}" fermée\`);
      } catch (e) { /* ignoré */ }
    }

    console.log('[RESTART] Lancement de START_ANA.bat...');

    // Lancer START_ANA.bat dans une nouvelle fenêtre (il nettoie les ports)
    spawn('cmd', ['/c', 'start', '', 'E:\\\\ANA\\\\START_ANA.bat']`;

if (content.includes(oldRestart)) {
  content = content.replace(oldRestart, newRestart);
  console.log('✅ Restart: ajout fermeture fenêtres avant START_ANA.bat');
} else {
  console.log('⚠️ Pattern restart non trouvé exactement');

  // Essayer un pattern plus simple
  const simpleOld = "console.log('[RESTART] Lancement de START_ANA.bat...');";
  if (content.includes(simpleOld)) {
    console.log('   Pattern simple trouvé, insertion manuelle...');
    const insertCode = `console.log('[RESTART] Fermeture des anciens terminaux Ana...');

    // FIX 2025-12-18: Fermer les fenêtres Ana AVANT de redémarrer
    const util = require('util');
    const execPromise = util.promisify(exec);
    const windowTitles = ['ChromaDB Server', 'Ana Interface Frontend', 'Ana Agents Autonomes', 'ComfyUI'];

    for (const title of windowTitles) {
      try {
        await execPromise(\`powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -like '*\${title}*'} | Stop-Process -Force -ErrorAction SilentlyContinue"\`);
        console.log(\`[RESTART] ✅ Fenêtre "\${title}" fermée\`);
      } catch (e) { /* ignoré */ }
    }

    `;
    content = content.replace(simpleOld, insertCode + simpleOld);
    console.log('✅ Restart: code de fermeture inséré');
  }
}

fs.writeFileSync(file, content, 'utf8');
console.log('');
console.log('═══════════════════════════════════════════════════════');
console.log('  CORRECTIONS APPLIQUÉES');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('Les boutons "Fermer Ana" et "Redémarrer Ana" fermeront');
console.log('maintenant TOUS les terminaux Ana avant de continuer.');
console.log('');
console.log('Redémarre Ana pour appliquer les changements.');
