#!/bin/bash
echo "Testing tool support for Ana models..."
for model in "qwen2.5-coder:7b" "qwen3:8b" "ana-superia-v6" "phi3:mini-128k"
do
  echo -n "Testing $model: "
  result=$(curl -s http://localhost:11434/api/chat -d "{\"model\": \"$model\", \"messages\": [{\"role\": \"user\", \"content\": \"Test\"}], \"tools\": [{\"name\": \"test\", \"description\": \"test\"}], \"stream\": false}")
  if echo "$result" | grep -q "does not support tools"; then
    echo "❌ NO TOOLS"
  else
    echo "✅ SUPPORTS TOOLS"
  fi
done
