const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Utiliser regex pour trouver le pattern
const regex = /(title="Sélectionner une voix"\s*>\s*\{availableVoices\.map)/;

if (regex.test(content) && !content.includes('sylvie-quebec')) {
  content = content.replace(regex, `title="Sélectionner une voix"
                    >
                      <option key="sylvie-quebec" value={SYLVIE_VOICE}>
                        Sylvie (Québec)
                      </option>
                      {availableVoices.map`);
  console.log('✓ Option Sylvie ajoutée au dropdown');
} else if (content.includes('sylvie-quebec')) {
  console.log('⚠ Sylvie déjà dans le dropdown');
} else {
  console.log('⚠ Pattern regex non trouvé');
  // Debug: montrer ce qui est autour
  const idx = content.indexOf('Sélectionner une voix');
  if (idx > -1) {
    console.log('Contexte trouvé autour de "Sélectionner une voix":');
    console.log(content.substring(idx, idx + 200));
  }
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
