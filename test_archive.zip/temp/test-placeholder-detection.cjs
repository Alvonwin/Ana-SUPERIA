/**
 * Test Placeholder Detection
 */
const visionRouter = require('../intelligence/vision/vision-router.cjs');

console.log('═══════════════════════════════════════════════════════');
console.log('  TEST DÉTECTION CHEMINS PLACEHOLDERS');
console.log('═══════════════════════════════════════════════════════');
console.log('');

// Chemins INVALIDES (inventés par le LLM)
const invalidPaths = [
  'C:\\Users\\nom\\Photos\\image.jpg',
  'C:\\Users\\username\\Desktop\\photo.jpg',
  'C:\\Users\\user\\Images\\test.png',
  'E:\\exemple\\image.jpg',
  'C:\\example\\photo.png',
  'C:\\nom_de_l_image.jpg',
  'image.jpg',
  'placeholder.png',
  '[chemin_image]',
  '<image_path>',
];

// Chemins VALIDES (vrais chemins utilisateur)
const validPaths = [
  'C:\\Users\\niwno\\Desktop\\photo.jpg',
  'E:\\ANA\\temp\\test.png',
  'E:\\Mémoire Claude\\screenshot_question.jpg',
  'C:\\Users\\niwno\\Documents\\image123.png',
];

console.log('--- CHEMINS INVALIDES (doivent être détectés) ---');
for (const path of invalidPaths) {
  const isPlaceholder = visionRouter.isPlaceholderPath(path);
  const status = isPlaceholder ? '✅ DÉTECTÉ' : '❌ NON DÉTECTÉ';
  console.log(`${status}: ${path}`);
}

console.log('');
console.log('--- CHEMINS VALIDES (ne doivent PAS être détectés) ---');
for (const path of validPaths) {
  const isPlaceholder = visionRouter.isPlaceholderPath(path);
  const status = isPlaceholder ? '❌ FAUX POSITIF' : '✅ OK';
  console.log(`${status}: ${path}`);
}

console.log('');
console.log('═══════════════════════════════════════════════════════');
