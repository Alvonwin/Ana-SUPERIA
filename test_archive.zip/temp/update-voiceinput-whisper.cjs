/**
 * Remplacer VoiceInput.jsx pour utiliser Whisper au lieu de Web Speech API
 */
const fs = require('fs');

const newContent = `import { useState, useRef } from 'react';
import './VoiceInput.css';
import { BACKEND_URL } from '../config.js';

/**
 * VoiceInput - Composant de reconnaissance vocale avec Whisper
 *
 * FIX 2025-12-17: Remplace Web Speech API par Whisper Medium
 * - Meilleure precision (surtout pour le francais quebecois)
 * - Supporte les mots anglais et noms propres (MétéoMédia, etc.)
 * - Utilise MediaRecorder pour capturer l'audio
 * - Envoie a /api/transcribe qui proxy vers Whisper:5001
 */

// Correction orthographique via backend (Anna -> Ana, etc.)
async function correctSpelling(text) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/spellcheck\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await response.json();
    if (data.success && data.corrected) {
      if (data.changed) {
        console.log('Correction:', text, '->', data.corrected);
      }
      return data.corrected;
    }
  } catch (e) {
    console.warn('Spell check failed:', e.message);
  }
  return text;
}

// Transcrire audio via Whisper
async function transcribeWithWhisper(audioBlob) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/transcribe\`, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/webm' },
      body: audioBlob
    });
    const data = await response.json();
    if (data.success && data.text) {
      console.log('[Whisper] Transcription:', data.text);
      return data.text;
    } else {
      throw new Error(data.error || 'Transcription failed');
    }
  } catch (e) {
    console.error('[Whisper] Error:', e.message);
    throw e;
  }
}

function VoiceInput({ onTranscript, onAutoSubmit, disabled = false }) {
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState('Pret');
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  const startRecording = async () => {
    if (disabled) {
      setStatus('Entree vocale desactivee');
      return;
    }

    try {
      // Demander acces au microphone
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 16000
        }
      });

      // Creer MediaRecorder
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });

      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        // Arreter le stream
        stream.getTracks().forEach(track => track.stop());

        // Creer blob audio
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        console.log('[VoiceInput] Audio captured:', audioBlob.size, 'bytes');

        if (audioBlob.size < 1000) {
          setStatus('Audio trop court');
          setIsProcessing(false);
          return;
        }

        // Transcrire avec Whisper
        setStatus('Transcription Whisper...');
        setIsProcessing(true);

        try {
          const rawTranscript = await transcribeWithWhisper(audioBlob);

          if (!rawTranscript || rawTranscript.trim() === '') {
            setStatus('Aucune parole detectee');
            setIsProcessing(false);
            return;
          }

          // Correction orthographique
          const transcript = await correctSpelling(rawTranscript);
          console.log('[VoiceInput] Final transcript:', transcript);

          if (onTranscript) {
            onTranscript(transcript);
          }

          setStatus('Transcription complete');

          // Auto-submit apres transcription
          if (onAutoSubmit) {
            console.log('[VoiceInput] Auto-submit:', transcript);
            setTimeout(() => {
              onAutoSubmit(transcript);
            }, 200);
          }

        } catch (error) {
          console.error('[VoiceInput] Whisper error:', error);
          setStatus('Erreur Whisper: ' + error.message);
        } finally {
          setIsProcessing(false);
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();

      setIsRecording(true);
      setStatus('Ecoute en cours...');
      console.log('[VoiceInput] Recording started');

    } catch (error) {
      console.error('[VoiceInput] Microphone error:', error);
      setStatus('Erreur microphone: ' + error.message);
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      console.log('[VoiceInput] Recording stopped');
    }
  };

  const handleClick = () => {
    if (isProcessing) {
      return; // Ignore clicks while processing
    }
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <div className="voice-input">
      <button
        className={\`voice-btn \${isRecording ? 'recording' : ''} \${isProcessing ? 'processing' : ''} \${disabled ? 'disabled' : ''}\`}
        onClick={handleClick}
        disabled={disabled || isProcessing}
        title={status}
      >
        {isProcessing ? (
          <span style={{ fontSize: '20px' }}>...</span>
        ) : isRecording ? (
          <span style={{ fontSize: '20px' }}>Stop</span>
        ) : (
          <span style={{ fontSize: '20px' }}>Mic</span>
        )}
      </button>
      {(isRecording || isProcessing) && (
        <div className="voice-status">
          <span className="pulse-dot"></span>
          {status}
        </div>
      )}
    </div>
  );
}

export default VoiceInput;
`;

const file = 'E:/ANA/ana-interface/src/components/VoiceInput.jsx';
fs.writeFileSync(file, newContent, 'utf8');
console.log('VoiceInput.jsx mis a jour pour utiliser Whisper');
