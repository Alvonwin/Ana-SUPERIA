/**
 * Update tool-agent.cjs to use vision-router
 */
const fs = require('fs');

const filePath = 'E:/ANA/server/agents/tool-agent.cjs';

// Read file
let content = fs.readFileSync(filePath, 'utf8');

// Backup
const backupPath = filePath + '.backup_vision_' + Date.now();
fs.writeFileSync(backupPath, content, 'utf8');
console.log('Backup created:', backupPath);

// 1. Replace import
const oldImport = `const LlamaVisionHandler = require('../../intelligence/vision/llama_vision_handler.cjs');
const visionHandler = new LlamaVisionHandler();`;

const newImport = `// Vision Router - Sélection intelligente Moondream (rapide) vs Llama Vision (puissant)
const visionRouter = require('../../intelligence/vision/vision-router.cjs');`;

if (content.includes(oldImport)) {
  content = content.replace(oldImport, newImport);
  console.log('✅ Import updated');
} else {
  console.log('⚠️ Import pattern not found, checking alternative...');
  if (content.includes('visionHandler')) {
    console.log('visionHandler found, needs manual update');
  }
}

// 2. Update describe_image
const oldDescribeImage = `  async describe_image(args) {
    const { image_path, image_base64, prompt } = args;
    console.log(\`👁️ [ToolAgent] describe_image: \${image_path || 'base64 image'}\`);
    try {
      const result = await visionHandler.analyzeImage({
        imagePath: image_path,
        imageBase64: image_base64,
        prompt: prompt || 'Décris cette image en détail.'
      });
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  },`;

const newDescribeImage = `  async describe_image(args) {
    const { image_path, image_base64, prompt } = args;
    console.log(\`👁️ [ToolAgent] describe_image: \${image_path || 'base64 image'}\`);
    try {
      // Utilise vision-router avec sélection automatique du modèle
      const result = await visionRouter.analyze({
        imagePath: image_path,
        imageBase64: image_base64,
        prompt: prompt || 'Décris cette image en détail.',
        taskType: 'description'  // Moondream (rapide) par défaut
      });
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  },`;

if (content.includes(oldDescribeImage)) {
  content = content.replace(oldDescribeImage, newDescribeImage);
  console.log('✅ describe_image updated');
} else {
  console.log('⚠️ describe_image pattern not found exactly');
}

// 3. Update debug_screenshot
const oldDebugScreenshot = `      const result = await visionHandler.analyzeImage({
        imagePath: image_path,
        imageBase64: image_base64,
        prompt: prompt
      });`;

const newDebugScreenshot = `      // Utilise Llama Vision (puissant) pour analyse de debug
      const result = await visionRouter.analyze({
        imagePath: image_path,
        imageBase64: image_base64,
        prompt: prompt,
        taskType: 'code',
        forceModel: 'powerful'  // Debug nécessite Llama Vision
      });`;

if (content.includes(oldDebugScreenshot)) {
  content = content.replace(oldDebugScreenshot, newDebugScreenshot);
  console.log('✅ debug_screenshot updated');
} else {
  console.log('⚠️ debug_screenshot pattern not found exactly');
}

// 4. Update analyze_code_screenshot
const oldAnalyzeCode = `      const result = await visionHandler.analyzeCodeScreenshot(image_path || { imageBase64: image_base64 });`;

const newAnalyzeCode = `      // Utilise Llama Vision pour analyse de code
      const result = await visionRouter.analyzeCode(image_path);`;

if (content.includes(oldAnalyzeCode)) {
  content = content.replace(oldAnalyzeCode, newAnalyzeCode);
  console.log('✅ analyze_code_screenshot updated');
} else {
  console.log('⚠️ analyze_code_screenshot pattern not found exactly');
}

// Write updated file
fs.writeFileSync(filePath, content, 'utf8');
console.log('');
console.log('File updated successfully!');
