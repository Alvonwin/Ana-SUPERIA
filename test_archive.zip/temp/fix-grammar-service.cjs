const fs = require('fs');

const filePath = 'E:/ANA/server/services/grammar-service.cjs';
let content = fs.readFileSync(filePath, 'utf8');

// Remplacer la méthode correct() par une version qui protège le code
const oldCorrect = `  async correct(text) {
    if (!this.enabled || !text || text.length < 5) {
      return text;
    }

    try {
      this.stats.checks++;

      const response = await axios.post(LANGUAGETOOL_API,`;

const newCorrect = `  async correct(text) {
    if (!this.enabled || !text || text.length < 5) {
      return text;
    }

    // === FIX 2025-12-17: Détecter et sauter les réponses de code ===
    // Si le texte contient des blocs de code ou du JSX, ne pas corriger
    const codeIndicators = [
      /\`\`\`/,           // Code blocks
      /\`[^\`]+\`/,       // Inline code
      /<[A-Z][a-zA-Z]*/, // JSX components like <Button
      /className=/,       // JSX attribute
      /onClick=/,         // Event handler
      /import .* from/,   // Import statement
      /export (default|const|function)/, // Export
      /const .* = /,      // Variable declaration
      /function \w+\(/,   // Function declaration
      /=> \{/,            // Arrow function
      /\.jsx|\.tsx|\.js|\.ts/, // File extensions
    ];

    for (const pattern of codeIndicators) {
      if (pattern.test(text)) {
        // Texte contient du code - ne pas corriger
        return text;
      }
    }

    try {
      this.stats.checks++;

      const response = await axios.post(LANGUAGETOOL_API,`;

if (content.includes(oldCorrect)) {
  content = content.replace(oldCorrect, newCorrect);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✅ grammar-service.cjs corrigé - Protection du code ajoutée');
} else {
  console.log('❌ Pattern non trouvé dans grammar-service.cjs');
  // Afficher le début de la fonction pour debug
  const match = content.match(/async correct\(text\) \{[\s\S]{0,200}/);
  if (match) {
    console.log('Trouvé:', match[0].substring(0, 100));
  }
}
