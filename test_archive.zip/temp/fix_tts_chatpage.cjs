const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Backup first
fs.writeFileSync(path + '.backup_tts', content, 'utf8');
console.log('✓ Backup créé');

// 1. Remplacer le bloc auto-speak (utilise regex pour gérer les whitespace)
const autoSpeakRegex = /\/\/ Déclencher l'audio après un délai pour laisser React mettre à jour le state\s+setTimeout\(\(\) => \{\s+if \(finalText && window\.speechSynthesis\) \{[\s\S]*?window\.speechSynthesis\.speak\(utterance\);\s+setPlayingAudio\(finalMessageId\);\s+\}\s+\}, 100\);/;

const newAutoSpeak = `// Déclencher l'audio après un délai pour laisser React mettre à jour le state
      setTimeout(async () => {
        if (finalText) {
          // PAUSE la reconnaissance vocale pendant le TTS
          if (voiceLoopRef.current) {
            voiceLoopRef.current.pause();
          }

          setPlayingAudio(finalMessageId);

          await ttsService.speak(finalText, {
            onEnd: () => {
              setPlayingAudio(null);
              console.log('✅ Sylvie a fini de parler');
              // RESUME la reconnaissance vocale après le TTS
              if (voiceLoopRef.current) {
                voiceLoopRef.current.resume();
              }
            },
            onError: (err) => {
              console.error('❌ Erreur TTS:', err);
              setPlayingAudio(null);
              if (voiceLoopRef.current) {
                voiceLoopRef.current.resume();
              }
            }
          });
        }
      }, 100);`;

if (autoSpeakRegex.test(content)) {
  content = content.replace(autoSpeakRegex, newAutoSpeak);
  console.log('✓ Auto-speak remplacé');
} else {
  console.log('⚠ Auto-speak pattern non trouvé');
}

// 2. Remplacer handlePlayPause
const playPauseRegex = /const handlePlayPause = \(messageId, text\) => \{\s+\/\/ Browser compatibility check\s+if \(!window\.speechSynthesis\)[\s\S]*?setPlayingAudio\(messageId\);\s+\} catch \(error\) \{[\s\S]*?\}\s+\};/;

const newPlayPause = `const handlePlayPause = async (messageId, text) => {
    if (playingAudio === messageId) {
      // Stop audio
      ttsService.stop();
      setPlayingAudio(null);
      return;
    }

    // Arrêter toute lecture en cours
    ttsService.stop();
    setPlayingAudio(messageId);

    try {
      await ttsService.speak(text, {
        onStart: () => {
          console.log('🔊 Sylvie parle...');
        },
        onEnd: () => {
          setPlayingAudio(null);
          console.log('✅ Lecture terminée');
        },
        onError: (error) => {
          console.error('❌ Erreur TTS:', error);
          setPlayingAudio(null);
          addSystemMessage('❌ Erreur synthèse vocale', 'error');
        }
      });
    } catch (error) {
      console.error('❌ Exception TTS:', error);
      addSystemMessage('❌ Erreur lors de la lecture audio', 'error');
      setPlayingAudio(null);
    }
  };`;

if (playPauseRegex.test(content)) {
  content = content.replace(playPauseRegex, newPlayPause);
  console.log('✓ handlePlayPause remplacé');
} else {
  console.log('⚠ handlePlayPause pattern non trouvé');
}

// Compter les occurrences restantes
const remaining = (content.match(/speechSynthesis/g) || []).length;
console.log('Occurrences speechSynthesis restantes:', remaining);

// Sauvegarder
fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
