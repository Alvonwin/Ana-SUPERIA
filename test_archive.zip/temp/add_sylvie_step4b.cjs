const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Utiliser regex pour trouver le pattern auto-speak
const regex = /\/\/ Déclencher l'audio après un délai pour laisser React mettre à jour le state\s+setTimeout\(\(\) => \{\s+if \(finalText && window\.speechSynthesis\) \{[\s\S]*?window\.speechSynthesis\.speak\(utterance\);\s+setPlayingAudio\(finalMessageId\);\s+\}\s+\}, 100\);/;

const newAutoSpeak = `// Déclencher l'audio après un délai pour laisser React mettre à jour le state
      setTimeout(async () => {
        if (finalText) {
          // PAUSE la reconnaissance vocale pendant le TTS
          if (voiceLoopRef.current) {
            voiceLoopRef.current.pause();
          }

          const onTTSEnd = () => {
            setPlayingAudio(null);
            console.log('✅ TTS terminé');
            if (voiceLoopRef.current) {
              voiceLoopRef.current.resume();
            }
          };

          // Utiliser Sylvie (edge-tts) ou voix navigateur
          if (selectedVoice?.name === SYLVIE_VOICE || !selectedVoice) {
            setPlayingAudio(finalMessageId);
            await speakWithEdgeTTS(finalText, onTTSEnd, onTTSEnd);
          } else if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(finalText);
            utterance.lang = 'fr-FR';
            utterance.rate = playbackRate;
            if (selectedVoice) utterance.voice = selectedVoice;
            utterance.onend = onTTSEnd;
            window.speechSynthesis.speak(utterance);
            setPlayingAudio(finalMessageId);
          }
        }
      }, 100);`;

if (regex.test(content)) {
  content = content.replace(regex, newAutoSpeak);
  console.log('✓ Auto-speak modifié pour Sylvie');
} else {
  console.log('⚠ Pattern regex auto-speak non trouvé');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
