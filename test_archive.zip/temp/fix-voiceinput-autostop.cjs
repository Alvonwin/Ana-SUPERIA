/**
 * VoiceInput avec arrêt automatique et icône micro
 */
const fs = require('fs');

const newContent = `import { useState, useRef, useEffect } from 'react';
import './VoiceInput.css';
import { BACKEND_URL } from '../config.js';

/**
 * VoiceInput - Reconnaissance vocale Whisper avec arrêt automatique
 * FIX 2025-12-17: Détection de silence pour arrêt auto
 */

async function correctSpelling(text) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/spellcheck\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await response.json();
    if (data.success && data.corrected) {
      if (data.changed) console.log('Correction:', text, '->', data.corrected);
      return data.corrected;
    }
  } catch (e) {
    console.warn('Spell check failed:', e.message);
  }
  return text;
}

async function transcribeWithWhisper(audioBlob) {
  try {
    const response = await fetch(\`\${BACKEND_URL}/api/transcribe\`, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/webm' },
      body: audioBlob
    });
    const data = await response.json();
    if (data.success && data.text) {
      console.log('[Whisper] Transcription:', data.text);
      return data.text;
    } else {
      throw new Error(data.error || 'Transcription failed');
    }
  } catch (e) {
    console.error('[Whisper] Error:', e.message);
    throw e;
  }
}

function VoiceInput({ onTranscript, onAutoSubmit, disabled = false }) {
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState('Pret');
  const [isProcessing, setIsProcessing] = useState(false);

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const streamRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const silenceTimerRef = useRef(null);
  const hasSpokenRef = useRef(false);

  // Constantes pour detection silence
  const SILENCE_THRESHOLD = 15; // Niveau sous lequel = silence
  const SILENCE_DURATION = 1500; // 1.5 secondes de silence = stop
  const MIN_RECORDING_TIME = 500; // Minimum 0.5s d'enregistrement

  const checkSilence = () => {
    if (!analyserRef.current || !isRecording) return;

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);

    // Calculer le volume moyen
    const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;

    if (average > SILENCE_THRESHOLD) {
      // Son detecte - reset timer silence
      hasSpokenRef.current = true;
      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = null;
      }
    } else if (hasSpokenRef.current && !silenceTimerRef.current) {
      // Silence apres avoir parle - demarrer timer
      silenceTimerRef.current = setTimeout(() => {
        console.log('[VoiceInput] Silence detecte - arret auto');
        stopRecording();
      }, SILENCE_DURATION);
    }

    // Continuer a verifier
    if (isRecording) {
      requestAnimationFrame(checkSilence);
    }
  };

  const startRecording = async () => {
    if (disabled || isProcessing) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true }
      });
      streamRef.current = stream;

      // Setup Web Audio API pour detection silence
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);

      // MediaRecorder
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      audioChunksRef.current = [];
      hasSpokenRef.current = false;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        // Cleanup
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
        }
        if (audioContextRef.current) {
          audioContextRef.current.close();
        }
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
        }

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        console.log('[VoiceInput] Audio:', audioBlob.size, 'bytes');

        if (audioBlob.size < 1000) {
          setStatus('Audio trop court');
          setIsProcessing(false);
          return;
        }

        setStatus('Transcription...');
        setIsProcessing(true);

        try {
          const rawTranscript = await transcribeWithWhisper(audioBlob);
          if (!rawTranscript || rawTranscript.trim() === '') {
            setStatus('Aucune parole');
            setIsProcessing(false);
            return;
          }

          const transcript = await correctSpelling(rawTranscript);
          console.log('[VoiceInput] Final:', transcript);

          if (onTranscript) onTranscript(transcript);
          setStatus('OK');

          if (onAutoSubmit) {
            setTimeout(() => onAutoSubmit(transcript), 200);
          }
        } catch (error) {
          console.error('[VoiceInput] Error:', error);
          setStatus('Erreur: ' + error.message);
        } finally {
          setIsProcessing(false);
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
      setStatus('Ecoute...');

      // Demarrer detection silence
      setTimeout(() => {
        checkSilence();
      }, MIN_RECORDING_TIME);

    } catch (error) {
      console.error('[VoiceInput] Mic error:', error);
      setStatus('Erreur micro');
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleClick = () => {
    if (isProcessing) return;
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="voice-input">
      <button
        className={\`voice-btn \${isRecording ? 'recording' : ''} \${isProcessing ? 'processing' : ''} \${disabled ? 'disabled' : ''}\`}
        onClick={handleClick}
        disabled={disabled || isProcessing}
        title={status}
      >
        {isProcessing ? (
          <span style={{ fontSize: '20px' }}>...</span>
        ) : isRecording ? (
          <span style={{ fontSize: '20px' }}>\\u23F9\\uFE0F</span>
        ) : (
          <span style={{ fontSize: '20px' }}>\\u{1F3A4}</span>
        )}
      </button>
      {(isRecording || isProcessing) && (
        <div className="voice-status">
          <span className="pulse-dot"></span>
          {status}
        </div>
      )}
    </div>
  );
}

export default VoiceInput;
`;

fs.writeFileSync('E:/ANA/ana-interface/src/components/VoiceInput.jsx', newContent, 'utf8');
console.log('VoiceInput.jsx mis a jour: arret auto + icone micro');
