const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Approche simplifiée: ajouter juste l'option Sylvie après le <select>
const selectStart = `title="Sélectionner une voix"
                    >
                      {availableVoices.map(voice => (`;

const selectWithSylvie = `title="Sélectionner une voix"
                    >
                      <option key="sylvie-quebec" value={SYLVIE_VOICE}>
                        Sylvie (Québec)
                      </option>
                      {availableVoices.map(voice => (`;

if (content.includes(selectStart) && !content.includes('sylvie-quebec')) {
  content = content.replace(selectStart, selectWithSylvie);
  console.log('✓ Option Sylvie ajoutée au dropdown');
} else if (content.includes('sylvie-quebec')) {
  console.log('⚠ Sylvie déjà dans le dropdown');
} else {
  console.log('⚠ Pattern select non trouvé');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
