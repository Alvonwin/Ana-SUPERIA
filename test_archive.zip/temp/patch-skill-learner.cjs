// Patch skill-learner.cjs pour ajouter apprentissage tool patterns
const fs = require('fs');
const filePath = 'E:/ANA/server/intelligence/skill-learner.cjs';

let content = fs.readFileSync(filePath, 'utf8');

// === PATCH 1: Modifier extractSkillsFromConversation pour accepter toolsUsed ===
const oldExtract = `  async extractSkillsFromConversation(exchange) {
    const { userMessage, anaResponse, model, success = true } = exchange;

    try {`;

const newExtract = `  async extractSkillsFromConversation(exchange) {
    const { userMessage, anaResponse, model, success = true, toolsUsed = {} } = exchange;

    // FIX 2025-12-17: Extraire tool patterns si des outils ont été utilisés
    if (Object.keys(toolsUsed).length > 0) {
      try {
        await this.extractToolPattern(userMessage, toolsUsed, success);
      } catch (e) {
        console.log('[SkillLearner] Tool pattern extraction skipped:', e.message);
      }
    }

    try {`;

if (content.includes(oldExtract)) {
  content = content.replace(oldExtract, newExtract);
  console.log('✅ Patch 1 appliqué (extractSkillsFromConversation modifié)');
} else {
  console.log('⚠️ Patch 1: Pattern non trouvé ou déjà appliqué');
}

// === PATCH 2: Ajouter les nouvelles méthodes avant la fin de la classe ===
const closingBrace = `
}

module.exports = new SkillLearner();`;

const newMethods = `

  // ========================================================
  // FIX 2025-12-17: Méthodes pour apprentissage tool patterns
  // ========================================================

  /**
   * Utilise semantic-router pour classifier le type de tâche
   */
  async getTaskType(message) {
    try {
      const semanticRouter = require('./semantic-router.cjs');
      if (!semanticRouter.initialized) {
        await semanticRouter.initialize();
      }
      const result = await semanticRouter.route(message);
      return result.taskType || 'conversation';
    } catch (e) {
      console.log('[SkillLearner] getTaskType fallback:', e.message);
      return 'conversation';
    }
  }

  /**
   * Extrait et stocke les patterns d'utilisation d'outils
   */
  async extractToolPattern(userMessage, toolsUsed, success) {
    const taskType = await this.getTaskType(userMessage);

    for (const [toolName, count] of Object.entries(toolsUsed)) {
      const pattern = {
        id: \`tp_\${Date.now()}_\${toolName}\`,
        type: 'tool_pattern',
        name: \`\${toolName}_for_\${taskType}\`,
        description: \`Outil \${toolName} efficace pour tâches \${taskType}\`,
        toolName: toolName,
        taskType: taskType,
        confidence: success ? 'high' : 'low',
        importance: 7,
        occurrences: 1,
        successCount: success ? 1 : 0,
        failureCount: success ? 0 : 1,
        learnedAt: new Date().toISOString(),
        lastSeen: new Date().toISOString()
      };

      // Vérifier si pattern similaire existe
      const existing = this.findSimilarToolPattern(toolName, taskType);
      if (existing) {
        existing.occurrences++;
        if (success) existing.successCount = (existing.successCount || 0) + 1;
        else existing.failureCount = (existing.failureCount || 0) + 1;
        existing.lastSeen = new Date().toISOString();
        // Ajuster confidence basé sur taux de succès
        const rate = existing.successCount / (existing.successCount + existing.failureCount);
        existing.confidence = rate > 0.8 ? 'high' : rate > 0.5 ? 'medium' : 'low';
      } else {
        if (!this.skills.skills) this.skills.skills = [];
        this.skills.skills.push(pattern);
      }
    }

    this.saveSkills();
    console.log(\`📚 [SkillLearner] Pattern appris: \${Object.keys(toolsUsed).join(', ')} pour \${taskType}\`);
  }

  /**
   * Trouve un tool pattern similaire existant
   */
  findSimilarToolPattern(toolName, taskType) {
    if (!this.skills?.skills) return null;
    return this.skills.skills.find(s =>
      s.type === 'tool_pattern' &&
      s.toolName === toolName &&
      s.taskType === taskType
    );
  }

  /**
   * Retourne les outils les plus efficaces pour un taskType
   */
  getRecommendedTools(taskType, limit = 5) {
    if (!this.skills?.skills) return [];

    return this.skills.skills
      .filter(s => s.type === 'tool_pattern' && s.taskType === taskType)
      .map(s => ({
        ...s,
        successRate: s.successCount / ((s.successCount || 0) + (s.failureCount || 0) || 1)
      }))
      .sort((a, b) => {
        // Priorité 1: taux de succès
        if (b.successRate !== a.successRate) return b.successRate - a.successRate;
        // Priorité 2: nombre d'occurrences (expérience)
        return (b.occurrences || 0) - (a.occurrences || 0);
      })
      .slice(0, limit);
  }
}

module.exports = new SkillLearner();`;

if (content.includes(closingBrace)) {
  content = content.replace(closingBrace, newMethods);
  console.log('✅ Patch 2 appliqué (nouvelles méthodes ajoutées)');
} else {
  console.log('⚠️ Patch 2: Pattern non trouvé');
}

// Sauvegarder
fs.writeFileSync(filePath, content, 'utf8');
console.log('Done - skill-learner.cjs patché');
