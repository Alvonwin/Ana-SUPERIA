const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Regex pour handlePlayPause
const regex = /const handlePlayPause = \(messageId, text\) => \{\s+\/\/ Browser compatibility check\s+if \(!window\.speechSynthesis\)[\s\S]*?setPlayingAudio\(messageId\);\s+\} catch \(error\) \{[\s\S]*?setPlayingAudio\(null\);\s+\}\s+\};/;

const newHandlePlayPause = `const handlePlayPause = async (messageId, text) => {
    // Si déjà en lecture, arrêter
    if (playingAudio === messageId) {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setPlayingAudio(null);
      return;
    }

    // Arrêter toute lecture en cours
    if (window.speechSynthesis) window.speechSynthesis.cancel();

    const onEnd = () => {
      setPlayingAudio(null);
      console.log('✅ Lecture audio terminée');
    };

    const onError = (err) => {
      console.error('❌ Erreur TTS:', err);
      setPlayingAudio(null);
      addSystemMessage('❌ Erreur synthèse vocale', 'error');
    };

    // Utiliser Sylvie (edge-tts) ou voix navigateur
    if (selectedVoice?.name === SYLVIE_VOICE || !selectedVoice) {
      setPlayingAudio(messageId);
      await speakWithEdgeTTS(text, onEnd, onError);
    } else if (window.speechSynthesis) {
      try {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'fr-FR';
        utterance.rate = playbackRate;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        if (selectedVoice) utterance.voice = selectedVoice;
        utterance.onend = onEnd;
        utterance.onerror = (event) => onError(event.error);
        window.speechSynthesis.speak(utterance);
        setPlayingAudio(messageId);
      } catch (error) {
        onError(error);
      }
    } else {
      addSystemMessage('❌ Synthèse vocale non supportée', 'error');
    }
  };`;

if (regex.test(content)) {
  content = content.replace(regex, newHandlePlayPause);
  console.log('✓ handlePlayPause modifié pour Sylvie');
} else {
  console.log('⚠ Pattern handlePlayPause non trouvé');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
