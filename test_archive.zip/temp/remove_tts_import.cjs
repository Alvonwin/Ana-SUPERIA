const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// Retire toutes les lignes contenant ttsService
const lines = content.split('\n');
const filtered = lines.filter(line => !line.includes('ttsService'));
content = filtered.join('\n');

fs.writeFileSync(path, content, 'utf8');

// Verifier
const newContent = fs.readFileSync(path, 'utf8');
const count = (newContent.match(/ttsService/g) || []).length;
console.log('ttsService restants:', count);
