/**
 * FIX 2025-12-18: Correction contextuelle "Astuce que" (erreur STT)
 */
const fs = require('fs');

const file = 'E:/ANA/server/utils/spell-checker.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
const backupFile = file + '.backup_astuce_' + Date.now();
fs.writeFileSync(backupFile, content, 'utf8');
console.log('✅ Backup créé:', backupFile);

// Pattern aveugle à remplacer
const oldPattern = `  text = text.replace(/astuce/gi, 'est-ce');`;

// Pattern contextuel (ne corrige que "Astuce que + pronom")
const newPattern = `  // FIX 2025-12-18: Correction contextuelle "Astuce que" (erreur STT)
  // Ne corrige QUE "Astuce que + pronom" (question mal transcrite)
  // Préserve "une astuce", "l'astuce", etc. (usage légitime)
  text = text.replace(/\\bastuce\\s+que\\s+(?=tu|il|elle|on|nous|vous|ils|elles|c'|ce|ça|j'|je)/gi, 'est-ce que ');
  text = text.replace(/\\bastuce\\s+qu['']/gi, "est-ce qu'");`;

if (content.includes(oldPattern)) {
  content = content.replace(oldPattern, newPattern);
  fs.writeFileSync(file, content, 'utf8');
  console.log('✅ Pattern "Astuce" corrigé (contextuel)');
  console.log('');
  console.log('Avant: text = text.replace(/astuce/gi, \'est-ce\');');
  console.log('Après: Correction contextuelle "Astuce que + pronom" seulement');
} else if (content.includes('Correction contextuelle "Astuce que"')) {
  console.log('ℹ️ Fix déjà appliqué');
} else {
  console.log('⚠️ Pattern non trouvé');
  // Chercher le contexte
  const lines = content.split('\n');
  lines.forEach((line, i) => {
    if (line.includes('astuce')) {
      console.log(`Ligne ${i + 1}: ${line}`);
    }
  });
}

console.log('\nRedémarre Ana pour appliquer.');
