/**
 * Fix: Cibler les titres EXACTS des fenêtres Ana
 * 18 Dec 2025
 */
const fs = require('fs');

const file = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
fs.writeFileSync(file + '.backup_exact_titles_' + Date.now(), content, 'utf8');
console.log('✅ Backup créé');

// Remplacer -like '*titre*' par -eq 'titre' (match exact)
// Pattern actuel avec exclusion Claude
const oldPattern1 = /-like '\*\$\{title\}\*'\) -and \(\$_\.MainWindowTitle -notlike '\*Claude\*'\)/g;
// Pattern original avec wildcard
const oldPattern2 = /-like '\*\$\{title\}\*'/g;

let modified = false;

if (oldPattern1.test(content)) {
  content = content.replace(oldPattern1, "-eq '${title}'");
  console.log('✅ Pattern avec exclusion Claude remplacé par match exact');
  modified = true;
}

// Reset regex lastIndex
oldPattern2.lastIndex = 0;
if (oldPattern2.test(content)) {
  content = content.replace(/-like '\*\$\{title\}\*'/g, "-eq '${title}'");
  console.log('✅ Pattern wildcard remplacé par match exact');
  modified = true;
}

if (!modified) {
  console.log('⚠️ Patterns non trouvés, vérification manuelle...');

  // Afficher les lignes contenant MainWindowTitle
  const lines = content.split('\n');
  lines.forEach((line, i) => {
    if (line.includes('MainWindowTitle')) {
      console.log(`Ligne ${i + 1}: ${line.trim()}`);
    }
  });
}

fs.writeFileSync(file, content, 'utf8');

console.log('');
console.log('═══════════════════════════════════════════════════════');
console.log('  CORRECTION APPLIQUÉE');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('Les boutons ciblent maintenant UNIQUEMENT:');
console.log('  - ChromaDB Server');
console.log('  - Ana Core Backend');
console.log('  - Ana Interface Frontend');
console.log('  - Ana Agents Autonomes');
console.log('  - ComfyUI');
console.log('');
console.log('Plus aucun autre processus ne sera fermé.');
console.log('Redémarre Ana pour appliquer.');
