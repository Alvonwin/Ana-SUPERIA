/**
 * Fix Vision - Détecter les chemins inventés/placeholders
 *
 * Problème: Le LLM invente des chemins comme "C:\Users\nom\Photos\image.jpg"
 * au lieu de demander le vrai chemin à l'utilisateur.
 *
 * Solution: Détecter ces patterns et retourner une erreur explicite
 */
const fs = require('fs');

// === 1. Mise à jour du vision-router.cjs ===

const visionRouterPath = 'E:/ANA/intelligence/vision/vision-router.cjs';
let visionRouter = fs.readFileSync(visionRouterPath, 'utf8');

// Backup
fs.writeFileSync(visionRouterPath + '.backup_placeholder_' + Date.now(), visionRouter, 'utf8');
console.log('✅ Backup vision-router.cjs');

// Ajouter la détection de placeholders dans imageToBase64
const oldImageToBase64 = `  imageToBase64(imagePath) {
    // Rejeter les URLs
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      throw new Error(\`Cette fonction ne supporte que les images LOCALES. "\${imagePath}" est une URL.\`);
    }`;

const newImageToBase64 = `  /**
   * Patterns de chemins inventés/placeholders à rejeter
   * Le LLM invente souvent ces chemins au lieu de demander le vrai
   */
  static PLACEHOLDER_PATTERNS = [
    /\\\\nom\\\\/i,                    // C:\\Users\\nom\\...
    /\\\\username\\\\/i,               // C:\\Users\\username\\...
    /\\\\user\\\\/i,                   // C:\\Users\\user\\...
    /\\\\exemple\\\\/i,                // ...\\exemple\\...
    /\\\\example\\\\/i,                // ...\\example\\...
    /nom_de_l[_']?image/i,          // nom_de_l_image.jpg
    /image\\d*\\.jpg$/i,             // image.jpg, image1.jpg
    /photo\\d*\\.jpg$/i,             // photo.jpg, photo1.jpg
    /exemple\\d*\\.(jpg|png)/i,      // exemple.jpg
    /example\\d*\\.(jpg|png)/i,      // example.jpg
    /test\\d*\\.(jpg|png)/i,         // test.jpg
    /placeholder/i,                  // placeholder
    /\\[.*\\]/,                       // [chemin] ou [image]
    /<.*>/,                          // <chemin> ou <image>
  ];

  /**
   * Vérifie si un chemin est un placeholder inventé par le LLM
   */
  isPlaceholderPath(imagePath) {
    for (const pattern of VisionRouter.PLACEHOLDER_PATTERNS) {
      if (pattern.test(imagePath)) {
        return true;
      }
    }
    return false;
  }

  imageToBase64(imagePath) {
    // === FIX 2025-12-17: Détecter les chemins inventés/placeholders ===
    if (this.isPlaceholderPath(imagePath)) {
      throw new Error(
        \`CHEMIN INVALIDE: "\${imagePath}" semble être un chemin inventé ou un exemple. \` +
        \`DEMANDE à l'utilisateur le chemin EXACT de l'image qu'il veut analyser. \` +
        \`Ne pas inventer de chemins!\`
      );
    }

    // Rejeter les URLs
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      throw new Error(\`Cette fonction ne supporte que les images LOCALES. "\${imagePath}" est une URL.\`);
    }`;

if (visionRouter.includes(oldImageToBase64)) {
  visionRouter = visionRouter.replace(oldImageToBase64, newImageToBase64);
  console.log('✅ Détection de placeholders ajoutée à vision-router.cjs');
} else {
  console.log('⚠️ Pattern imageToBase64 non trouvé exactement dans vision-router');
}

fs.writeFileSync(visionRouterPath, visionRouter, 'utf8');

// === 2. Mise à jour de la définition du tool describe_image ===

const toolAgentPath = 'E:/ANA/server/agents/tool-agent.cjs';
let toolAgent = fs.readFileSync(toolAgentPath, 'utf8');

// Backup
fs.writeFileSync(toolAgentPath + '.backup_placeholder_' + Date.now(), toolAgent, 'utf8');
console.log('✅ Backup tool-agent.cjs');

// Améliorer la description du tool
const oldToolDef = `      name: 'describe_image',
      description: 'Analyser une image LOCALE sur le PC. REGLE CRITIQUE: Quand l\\'utilisateur fournit un chemin comme "C:\\\\Users\\\\...\\\\image.jpg", tu DOIS utiliser CE CHEMIN EXACT dans image_path. NE JAMAIS inventer de chemin ni d\\'URL. Copie EXACTEMENT le chemin fourni.',`;

const newToolDef = `      name: 'describe_image',
      description: 'Analyser une image LOCALE. REGLES STRICTES: 1) Tu ne peux appeler cet outil QUE si l\\'utilisateur a fourni un chemin EXACT et COMPLET (ex: C:\\\\Users\\\\niwno\\\\Desktop\\\\photo.jpg). 2) Si l\\'utilisateur dit juste "regarde cette image" SANS chemin, tu DOIS lui DEMANDER le chemin avant d\\'appeler cet outil. 3) NE JAMAIS inventer de chemin comme "C:\\\\Users\\\\nom\\\\..." - demande TOUJOURS le vrai chemin.',`;

if (toolAgent.includes(oldToolDef)) {
  toolAgent = toolAgent.replace(oldToolDef, newToolDef);
  console.log('✅ Description describe_image améliorée');
} else {
  console.log('⚠️ Pattern describe_image definition non trouvé exactement');
}

fs.writeFileSync(toolAgentPath, toolAgent, 'utf8');

// === 3. Mise à jour du system prompt Ana ===

const llmProfilesPath = 'E:/ANA/server/config/llm-profiles.cjs';
let llmProfiles = fs.readFileSync(llmProfilesPath, 'utf8');

// Backup
fs.writeFileSync(llmProfilesPath + '.backup_placeholder_' + Date.now(), llmProfiles, 'utf8');
console.log('✅ Backup llm-profiles.cjs');

// Améliorer la règle 6
const oldRule6 = `6. IMAGES LOCALES: Quand l'utilisateur donne un chemin d'image (ex: C:\\\\Users\\\\...\\\\photo.jpg), utilise describe_image avec CE CHEMIN EXACT. Ne jamais inventer de chemin ni URL.`;

const newRule6 = `6. IMAGES: Tu ne peux analyser une image QUE si l'utilisateur te donne le chemin EXACT et COMPLET. Si l'utilisateur dit "regarde cette image" SANS chemin, DEMANDE-LUI: "Quel est le chemin exact de l'image? (ex: C:\\\\Users\\\\ton_nom\\\\Desktop\\\\photo.jpg)". NE JAMAIS inventer de chemin!`;

if (llmProfiles.includes(oldRule6)) {
  llmProfiles = llmProfiles.replace(oldRule6, newRule6);
  console.log('✅ Règle 6 du system prompt améliorée');
} else {
  console.log('⚠️ Règle 6 non trouvée exactement - vérification manuelle requise');
  // Afficher ce qui existe
  const match = llmProfiles.match(/6\. .*IMAGES?.*/i);
  if (match) {
    console.log('   Trouvé:', match[0].substring(0, 100));
  }
}

fs.writeFileSync(llmProfilesPath, llmProfiles, 'utf8');

console.log('');
console.log('═══════════════════════════════════════════════════════');
console.log('  CORRECTIONS APPLIQUÉES');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('1. vision-router.cjs:');
console.log('   - Détecte les chemins placeholder (nom, username, example...)');
console.log('   - Retourne erreur explicite demandant le vrai chemin');
console.log('');
console.log('2. tool-agent.cjs:');
console.log('   - Description plus stricte: demander chemin SI non fourni');
console.log('');
console.log('3. llm-profiles.cjs:');
console.log('   - Règle 6 renforcée: DEMANDER le chemin si absent');
console.log('');
