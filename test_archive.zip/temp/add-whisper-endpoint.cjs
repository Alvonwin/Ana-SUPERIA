/**
 * Ajouter endpoint /api/transcribe dans ana-core.cjs
 * Proxy vers Whisper STT local (port 5001)
 */
const fs = require('fs');

const file = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(file, 'utf8');

// Pattern à chercher
const searchPattern = `});

// ================== CODE EXECUTE API (Fix #3 - 30-Nov-2025) ==================
// Sandboxed JavaScript execution with timeout
// Design: Perplexity - Phase 1 (JS only, vm sandbox, 3s timeout)

const CODE_EXEC_TIMEOUT = 3000;`;

// Nouveau code à insérer
const newCode = `});

// ================== WHISPER STT API (17-Dec-2025) ==================
// Proxy vers le service Whisper STT local (port 5001)
// Transcription vocale de haute qualité (Whisper Medium)

const { execSync } = require('child_process');
const os = require('os');
const pathModule = require('path');

app.post('/api/transcribe', express.raw({ type: '*/*', limit: '50mb' }), async (req, res) => {
  const tempFile = pathModule.join(os.tmpdir(), \`ana_audio_\${Date.now()}.webm\`);

  try {
    // Sauvegarder l'audio temporairement
    require('fs').writeFileSync(tempFile, req.body);
    console.log('[WHISPER] Audio reçu:', tempFile, req.body.length, 'bytes');

    // Appeler le service Whisper via curl
    const curlCmd = \`curl -s -X POST -F "audio=@\${tempFile}" http://localhost:5001/transcribe\`;
    const result = execSync(curlCmd, { encoding: 'utf8', timeout: 120000 });

    // Nettoyer le fichier temporaire
    try { require('fs').unlinkSync(tempFile); } catch (e) {}

    // Parser et retourner le résultat
    const parsed = JSON.parse(result);
    console.log('[WHISPER] Transcription:', parsed.text);

    res.json({
      success: true,
      text: parsed.text || '',
      source: 'whisper-medium'
    });

  } catch (error) {
    // Nettoyer en cas d'erreur
    try { require('fs').unlinkSync(tempFile); } catch (e) {}

    console.error('[WHISPER] Erreur:', error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      text: ''
    });
  }
});

// ================== CODE EXECUTE API (Fix #3 - 30-Nov-2025) ==================
// Sandboxed JavaScript execution with timeout
// Design: Perplexity - Phase 1 (JS only, vm sandbox, 3s timeout)

const CODE_EXEC_TIMEOUT = 3000;`;

if (content.includes(searchPattern)) {
  content = content.replace(searchPattern, newCode);
  fs.writeFileSync(file, content, 'utf8');
  console.log('✅ Endpoint /api/transcribe ajouté à ana-core.cjs');
} else if (content.includes('/api/transcribe')) {
  console.log('ℹ️ Endpoint /api/transcribe déjà présent');
} else {
  console.log('❌ Pattern non trouvé');
}
