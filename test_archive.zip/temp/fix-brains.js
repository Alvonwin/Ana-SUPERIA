const fs = require('fs');
let content = fs.readFileSync('E:/ANA/ana-interface/src/pages/BrainsPage.jsx', 'utf8');

// Réparer le bloc corrompu - supprimer les lignes groq orphelines
content = content.replace(
  /body = \{ message: testMessage \};\n\s*\/api\/groq\/chat`;\n\s*body = \{ message: testMessage, model \};\n\s*\} else if \(provider === 'cerebras'\)/,
  "body = { message: testMessage };\n      } else if (provider === 'cerebras')"
);

// Supprimer les case groq restants
content = content.replace(/case 'groq': return '[^']*';\n\s*/g, '');

fs.writeFileSync('E:/ANA/ana-interface/src/pages/BrainsPage.jsx', content, 'utf8');
console.log('Done');
