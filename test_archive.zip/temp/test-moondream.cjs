/**
 * Test Moondream 2 vision model speed
 */
const fs = require('fs');
const axios = require('axios');

const imagePath = 'E:/Mémoire Claude/screenshot_question.jpg';

async function test() {
  const imageBuffer = fs.readFileSync(imagePath);
  const base64 = imageBuffer.toString('base64');

  console.log('Image size:', Math.round(imageBuffer.length / 1024), 'KB');
  console.log('Testing Moondream 2...');

  const start = Date.now();
  try {
    const response = await axios.post('http://localhost:11434/api/generate', {
      model: 'moondream',
      prompt: 'Describe this image briefly.',
      images: [base64],
      stream: false
    }, { timeout: 60000 });

    const ms = Date.now() - start;
    console.log('');
    console.log('SUCCESS in', ms, 'ms');
    console.log('Response:', response.data.response);
  } catch (e) {
    console.log('ERROR:', e.message);
  }
}

test();
