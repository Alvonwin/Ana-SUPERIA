const fs = require('fs');
const path = 'E:/ANA/ana-interface/src/pages/ChatPage.jsx';
let content = fs.readFileSync(path, 'utf8');

// 2. Ajouter la fonction speakWithEdgeTTS après handleRateChange
const rateChangeEnd = "console.log('⚡ Vitesse changée:', rate + 'x');\n  };";

const speakFunction = `console.log('⚡ Vitesse changée:', rate + 'x');
  };

  // Synthèse vocale avec Sylvie (edge-tts backend)
  const speakWithEdgeTTS = async (text, onEnd, onError) => {
    try {
      const response = await fetch(\`\${BACKEND_URL}/api/tts/synthesize\`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      if (!response.ok) throw new Error('TTS failed');
      const blob = await response.blob();
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      audio.onended = () => {
        URL.revokeObjectURL(audioUrl);
        if (onEnd) onEnd();
      };
      audio.onerror = (err) => {
        URL.revokeObjectURL(audioUrl);
        if (onError) onError(err);
      };
      await audio.play();
      return audio;
    } catch (err) {
      console.error('Edge-TTS error:', err);
      if (onError) onError(err);
      return null;
    }
  };`;

if (!content.includes('speakWithEdgeTTS')) {
  content = content.replace(rateChangeEnd, speakFunction);
  console.log('✓ Fonction speakWithEdgeTTS ajoutée');
} else {
  console.log('⚠ speakWithEdgeTTS déjà présent');
}

fs.writeFileSync(path, content, 'utf8');
console.log('✓ Fichier sauvegardé');
