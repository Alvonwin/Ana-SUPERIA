// Patch spell-checker.cjs pour corriger "puisage" et autres erreurs LLM
const fs = require('fs');
const path = 'E:/ANA/server/utils/spell-checker.cjs';

let content = fs.readFileSync(path, 'utf8');

// Utiliser regex pour être plus flexible avec whitespace
const pattern = /function correctText\(text\) \{[\r\n\s]+if \(!spellChecker \|\| !text\) return text;[\r\n\s]+\/\/ Split text into words/;

const replacement = `function correctText(text) {
  if (!spellChecker || !text) return text;

  // ═══ CORRECTIONS CONTEXTUELLES (erreurs LLM connues) ═══
  // "puisage" est un mot valide (puiser eau) mais nonsensique dans "Comment puisage t'aider"
  text = text.replace(/\\bpuisage\\b/gi, 'puis-je');
  text = text.replace(/\\bajoure['']?fui\\b/gi, "aujourd'hui");
  text = text.replace(/\\bconnecte\\b/g, 'connectée');  // accord féminin pour Ana

  // Split text into words`;

if (pattern.test(content)) {
  content = content.replace(pattern, replacement);
  fs.writeFileSync(path, content, 'utf8');
  console.log('✓ spell-checker.cjs patché - corrections contextuelles ajoutées');
} else if (content.includes('puisage')) {
  console.log('✓ Déjà patché!');
} else {
  console.log('✗ Pattern regex non trouvé');
}
