// Patch ana-direct.cjs pour ajouter extraction de tool patterns
const fs = require('fs');
const filePath = 'E:/ANA/server/intelligence/ana-direct.cjs';

let content = fs.readFileSync(filePath, 'utf8');

// Pattern à remplacer
const oldPattern = `    const result = await toolAgent.runToolAgentV2(message, {
      model: 'cerebras/llama-3.3-70b',
      sessionId: options.sessionId || 'chat_direct',
      context: enhancedContext,
      timeoutMs: 120000  // 2 minutes max
    });

    const duration = Date.now() - startTime;
    console.log(\`[ANA-DIRECT] Réponse reçue en \${duration}ms\`);`;

const newPattern = `    const result = await toolAgent.runToolAgentV2(message, {
      model: 'cerebras/llama-3.3-70b',
      sessionId: options.sessionId || 'chat_direct',
      context: enhancedContext,
      timeoutMs: 120000  // 2 minutes max
    });

    // FIX 2025-12-17: Extraire tool patterns pour apprentissage
    const toolsUsedDirect = result?.stats?.toolCallCounts || {};
    if (Object.keys(toolsUsedDirect).length > 0) {
      try {
        const skillLearner = require('./skill-learner.cjs');
        skillLearner.extractSkillsFromConversation({
          userMessage: message,
          anaResponse: result.answer || '',
          model: result.model || 'cerebras/llama-3.3-70b',
          success: result.success,
          toolsUsed: toolsUsedDirect
        }).catch(e => console.log('📚 Skill extraction skipped:', e.message));
      } catch (e) {
        console.log('📚 Skill extraction error:', e.message);
      }
    }

    const duration = Date.now() - startTime;
    console.log(\`[ANA-DIRECT] Réponse reçue en \${duration}ms\`);`;

if (content.includes(oldPattern)) {
  content = content.replace(oldPattern, newPattern);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✅ Patch appliqué à ana-direct.cjs');
} else {
  console.log('⚠️ Pattern non trouvé ou déjà patché');
  // Debug
  const idx = content.indexOf('runToolAgentV2');
  if (idx > 0) {
    console.log('Contexte trouvé:', content.substring(idx - 50, idx + 300));
  }
}
