/**
 * Fix: Nettoyer préfixe data:image pour Ollama
 * 18 Dec 2025
 */
const fs = require('fs');

const file = 'E:/ANA/intelligence/vision/vision-router.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
fs.writeFileSync(file + '.backup_base64_' + Date.now(), content, 'utf8');
console.log('✅ Backup créé');

// Pattern à remplacer
const oldCode = `if (imageBase64) {
        base64 = imageBase64;
      }`;

const newCode = `if (imageBase64) {
        base64 = imageBase64;
        // FIX 2025-12-18: Nettoyer le préfixe data:image si présent (Ollama attend base64 pur)
        if (base64.includes(',')) {
          base64 = base64.split(',')[1];
          this.log('Préfixe data:image nettoyé');
        }
      }`;

if (content.includes(oldCode)) {
  content = content.replace(oldCode, newCode);
  fs.writeFileSync(file, content, 'utf8');
  console.log('✅ Fix appliqué: nettoyage préfixe data:image');
} else if (content.includes('Préfixe data:image nettoyé')) {
  console.log('ℹ️ Fix déjà appliqué');
} else {
  console.log('⚠️ Pattern non trouvé, vérification manuelle nécessaire');
  // Afficher le contexte
  const lines = content.split('\n');
  lines.forEach((line, i) => {
    if (line.includes('imageBase64')) {
      console.log(`Ligne ${i + 1}: ${line}`);
    }
  });
}

console.log('');
console.log('Redémarre Ana pour appliquer.');
