/**
 * Fix: Exclure Claude Code de la fermeture
 * 18 Dec 2025
 */
const fs = require('fs');

const file = 'E:/ANA/server/ana-core.cjs';
let content = fs.readFileSync(file, 'utf8');

// Backup
fs.writeFileSync(file + '.backup_exclude_claude_' + Date.now(), content, 'utf8');
console.log('✅ Backup créé');

// Ancien code PowerShell (dans shutdown)
const oldPowershell = `await execPromise(\`powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -like '*\${title}*'} | Stop-Process -Force -ErrorAction SilentlyContinue"\`);`;

// Nouveau code: exclure Claude
const newPowershell = `await execPromise(\`powershell -Command "Get-Process | Where-Object {($_.MainWindowTitle -like '*\${title}*') -and ($_.MainWindowTitle -notlike '*Claude*')} | Stop-Process -Force -ErrorAction SilentlyContinue"\`);`;

const count = (content.match(new RegExp(oldPowershell.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
console.log(`Occurrences trouvées: ${count}`);

if (count > 0) {
  content = content.split(oldPowershell).join(newPowershell);
  console.log('✅ PowerShell modifié: exclut maintenant "*Claude*"');
} else {
  console.log('⚠️ Pattern PowerShell non trouvé, recherche alternative...');

  // Rechercher le pattern avec des variations possibles
  if (content.includes("MainWindowTitle -like '*${title}*'") && content.includes('Stop-Process')) {
    content = content.replace(
      /\(\$_\.MainWindowTitle -like '\*\$\{title\}\*'\)/g,
      "(($$_.MainWindowTitle -like '*${title}*') -and ($$_.MainWindowTitle -notlike '*Claude*'))"
    );
    console.log('✅ Pattern alternatif corrigé');
  }
}

fs.writeFileSync(file, content, 'utf8');
console.log('');
console.log('═══════════════════════════════════════════════════════');
console.log('  CORRECTION APPLIQUÉE');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('Claude Code ne sera plus fermé par les boutons.');
console.log('Redémarre Ana pour appliquer.');
