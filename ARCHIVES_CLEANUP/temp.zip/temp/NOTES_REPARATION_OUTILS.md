# NOTES DE RÉPARATION - OUTILS ANA

## Problème: 181 outils = 15,466 tokens
- Le payload des 181 outils fait 61,862 caractères (~15k tokens)
- qwen3:8b (32k context) refuse d'utiliser les tools quand il y en a trop
- SOLUTION NÉCESSAIRE: Grouper les outils par catégorie

## Groupes d'outils suggérés:

### Groupe 1: WEB & API (web_search, get_weather, get_time, wikipedia, web_fetch, http_request)
### Groupe 2: FICHIERS (read_file, write_file, list_files, edit_file, glob, grep, etc.)
### Groupe 3: SYSTÈME (get_cpu_usage, get_memory_usage, get_disk_usage, ping, etc.)
### Groupe 4: GIT (git_status, git_log, git_branch, git_diff, etc.)
### Groupe 5: DOCKER (docker_ps, docker_images, docker_logs, etc.)
### Groupe 6: OLLAMA (ollama_list, ollama_chat, ollama_pull, etc.)
### Groupe 7: IMAGE (generate_image, describe_image, resize_image, etc.)
### Groupe 8: CONVERSION (json_to_csv, xml_to_json, yaml_to_json, etc.)
### Groupe 9: CRYPTO (hash_file, encrypt_text, generate_uuid, etc.)
### Groupe 10: NPM (npm_list, npm_search, npm_info, etc.)

## Corrections effectuées (2025-12-11):

### 1. ana-consciousness.cjs
- Changé `expertType: "research"` → `expertType: "tools"` pour recherche web
- Ajouté règles 9-17 (météo, heure, images, git, docker, ollama, wikipedia, npm)
- Exemples génériques au lieu de valeurs hardcodées
- Backup: E:/ANA/temp/BACKUP_CYCLE_2025-12-11/ana-consciousness.cjs.backup

### 2. ana-core.cjs (routing)
- Retiré `'mon ', 'ma ', 'mes ', 'quelle est'` des memoryKeywords
- Ces mots trop génériques faisaient router vers French model au lieu de tools
- Backup: E:/ANA/temp/BACKUP_CYCLE_2025-12-11/ana-core.cjs.backup_routing

### 3. architect-agent.cjs
- Changé `callWithFallback(prompt, {options})` → `callWithFallback(messages, null, {options})`
- La fonction attend un array de messages, pas une string
- Backup: E:/ANA/temp/BACKUP_CYCLE_2025-12-11/architect-agent.cjs.backup

### 4. llama_vision_handler.cjs
- Changé model name de `llama3.2-vision:11b-instruct-q4_K_M` → `llama3.2-vision:11b`
- Le modèle installé s'appelle simplement llama3.2-vision:11b
- Backup: E:/ANA/temp/BACKUP_CYCLE_2025-12-11/llama_vision_handler.cjs.backup

## Procédure de test météo:
1. Envoyer: "Quelle est la météo à [ville]?"
2. Le routing doit matcher 'météo' dans toolsKeywords
3. La conscience doit générer expertType: "tools", expertQuery: "Utilise get_weather pour [ville]"
4. L'orchestrateur doit envoyer les tools à qwen3:8b
5. qwen3:8b doit retourner tool_calls avec get_weather
6. Le tool_agent doit exécuter get_weather et retourner le résultat

## SOLUTION IMPLÉMENTÉE (2025-12-11):

### 5. tool-groups.cjs (NOUVEAU FICHIER)
- Créé E:/ANA/server/core/tool-groups.cjs
- Définit 18 groupes d'outils: web, files, system, git, docker, ollama, image, conversion, crypto, npm, archive, datetime, audio, browser, database, memory, code, agents, validation, utils, youtube
- Fonction `detectToolGroups(query)` détecte le groupe selon les mots-clés
- Fonction `getRelevantTools(allTools, query)` filtre les outils

### 6. tool-agent.cjs
- Ajouté import: `const { getRelevantTools } = require('../core/tool-groups.cjs');`
- Ligne 7149: Remplacé `TOOL_DEFINITIONS` par `filteredTools`
- Ligne 7513: Idem pour `continueConversation`
- Avant: 181 outils = ~15,000 tokens
- Après: ~10-20 outils = ~1,000 tokens par groupe
- Backup: E:/ANA/temp/BACKUP_CYCLE_2025-12-11/tool-agent.cjs.backup_groupes

## Résultat attendu:
- "météo Longueuil" → groupe 'web' → ~11 outils dont get_weather
- qwen3:8b devrait maintenant faire des tool_calls correctement
